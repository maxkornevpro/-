import json
import uuid
from datetime import datetime, timedelta

import paramiko

from config import (
    VPN_NAME,
    VPS_DOMAIN,
    VPS_HOST,
    VPS_PASSWORD,
    VPS_PORT,
    VPS_PUBLIC_KEY,
    VPS_USER,
    VPS2_DOMAIN,
    VPS2_HOST,
    VPS2_PASSWORD,
    VPS2_PORT,
    VPS2_PUBLIC_KEY,
    VPS2_USER,
    VPS3_DOMAIN,
    VPS3_HOST,
    VPS3_PASSWORD,
    VPS3_PORT,
    VPS3_PUBLIC_KEY,
    VPS3_USER,
)
from panel_3xui import get_estonia_panel, get_germany_panel, get_sweden_panel


GERMANY_PUBLIC_KEY = VPS3_PUBLIC_KEY


class VPNManager:
    def __init__(self, host=None, port=None, user=None, password=None):
        self.host = host or VPS3_HOST
        self.port = port or VPS3_PORT

        if self.host == VPS2_HOST:
            self.user = user or VPS2_USER
            self.password = password or VPS2_PASSWORD
        elif self.host == VPS3_HOST:
            self.user = user or VPS3_USER
            self.password = password or VPS3_PASSWORD
        else:
            self.user = user or VPS_USER
            self.password = password or VPS_PASSWORD

    def _connect(self):
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(self.host, username=self.user, password=self.password, timeout=30)
        return client

    def add_user_to_server(self, user_uuid, short_id):
        client = self._connect()
        try:
            config = None
            for path in (
                "/usr/local/etc/xray/config.json",
                "/etc/xray/config.json",
                "/usr/local/etc/xray/config.json",
            ):
                stdin, stdout, stderr = client.exec_command(f"cat {path}")
                raw = stdout.read().decode(errors="ignore").strip()
                if not raw:
                    continue
                try:
                    config = json.loads(raw)
                    break
                except Exception:
                    continue

            if not config:
                return False

            new_client = {
                "id": user_uuid,
                "flow": "xtls-rprx-vision",
            }

            clients = config["inbounds"][0]["settings"]["clients"]
            existing_ids = [item["id"] for item in clients]
            if user_uuid in existing_ids:
                return True

            clients.append(new_client)
            config_json = json.dumps(config, indent=2)
            command = f"cat > /usr/local/etc/xray/config.json << 'EOF'\n{config_json}\nEOF"
            client.exec_command(command)
            client.exec_command("systemctl reload xray || systemctl restart xray")
            return True
        finally:
            client.close()

    def remove_user_from_server(self, user_uuid):
        client = self._connect()
        try:
            stdin, stdout, stderr = client.exec_command("cat /usr/local/etc/xray/config.json")
            config = json.loads(stdout.read().decode())

            clients = config["inbounds"][0]["settings"]["clients"]
            config["inbounds"][0]["settings"]["clients"] = [
                client_item for client_item in clients if client_item["id"] != user_uuid
            ]

            config_json = json.dumps(config, indent=2)
            command = f"cat > /usr/local/etc/xray/config.json << 'EOF'\n{config_json}\nEOF"
            client.exec_command(command)
            client.exec_command("systemctl reload xray || systemctl restart xray")
            return True
        finally:
            client.close()

    def _add_client_via_best_method(self, host, user, password, panel_getter, user_uuid, email, days):
        try:
            panel = panel_getter()
            if panel:
                result = panel.add_client(
                    email=email,
                    client_id=user_uuid,
                    expiry_days=days or 0,
                    traffic_gb=0,
                )
                if result:
                    return True
        except Exception as exc:
            print(f"3x-ui error on {host}: {exc}")

        fallback = VPNManager(host=host, port=8443, user=user, password=password)
        return fallback.add_user_to_server(user_uuid, "e206aab7f52ddc90")

    def generate_vpn_key(self, user_id, days=None, use_3xui=True):
        user_uuid = str(uuid.uuid4())
        short_id = "e206aab7f52ddc90"
        email = f"user_{user_id}_{uuid.uuid4().hex[:8]}@aeroprojectvpn.com"

        expires_at = datetime.now() + timedelta(days=days) if days else None

        germany_ok = self._add_client_via_best_method(
            host=VPS3_HOST,
            user=VPS3_USER,
            password=VPS3_PASSWORD,
            panel_getter=get_germany_panel,
            user_uuid=user_uuid,
            email=email,
            days=days,
        )
        estonia_ok = self._add_client_via_best_method(
            host=VPS2_HOST,
            user=VPS2_USER,
            password=VPS2_PASSWORD,
            panel_getter=get_estonia_panel,
            user_uuid=user_uuid,
            email=email,
            days=days,
        )
        sweden_ok = self._add_client_via_best_method(
            host=VPS_HOST,
            user=VPS_USER,
            password=VPS_PASSWORD,
            panel_getter=get_sweden_panel,
            user_uuid=user_uuid,
            email=email,
            days=days,
        )
        
        if not germany_ok and not estonia_ok and not sweden_ok:
            raise RuntimeError("Failed to add client to all VPN servers")

        # Generate VLESS link for Germany without port if using 443
        if VPS3_PORT == 443:
            vless_link = (
                f"vless://{user_uuid}@{VPS3_DOMAIN}?"
                f"flow=xtls-rprx-vision&encryption=none&security=reality&"
                f"sni=www.google.com&fp=chrome&pbk={GERMANY_PUBLIC_KEY}&"
                f"sid={short_id}&type=tcp&headerType=none#🇩🇪 Германия (Fast)"
            )
        else:
            vless_link = (
                f"vless://{user_uuid}@{VPS3_DOMAIN}:{VPS3_PORT}?"
                f"flow=xtls-rprx-vision&encryption=none&security=reality&"
                f"sni=www.google.com&fp=chrome&pbk={GERMANY_PUBLIC_KEY}&"
                f"sid={short_id}&type=tcp&headerType=none#🇩🇪 Германия (Fast)"
            )

        return {
            "uuid": user_uuid,
            "public_key": GERMANY_PUBLIC_KEY,
            "private_key": "",
            "short_id": short_id,
            "expires_at": expires_at,
            "vless_link": vless_link,
            "server": "multi",
            "domain": VPS_DOMAIN,
            "email": email,
            "servers": [
                {
                    "name": "germany",
                    "host": VPS3_DOMAIN,
                    "port": VPS3_PORT,
                    "public_key": GERMANY_PUBLIC_KEY,
                },
                {
                    "name": "estonia",
                    "host": VPS2_DOMAIN,
                    "port": VPS2_PORT,
                    "public_key": VPS2_PUBLIC_KEY,
                },
                {
                    "name": "sweden",
                    "host": VPS_DOMAIN,
                    "port": VPS_PORT,
                    "public_key": VPS_PUBLIC_KEY,
                },
            ],
        }

    def remove_key_from_all_servers(self, client_id: str) -> bool:
        """Remove a client from all VPN servers."""
        removed_any = False
        
        # Try Germany via 3x-ui
        try:
            panel = get_germany_panel()
            if panel and panel.delete_client(client_id):
                removed_any = True
                print(f"Removed client {client_id} from Germany")
        except Exception as exc:
            print(f"Germany remove error: {exc}")
        
        # Try Estonia via 3x-ui
        try:
            panel = get_estonia_panel()
            if panel and panel.delete_client(client_id):
                removed_any = True
                print(f"Removed client {client_id} from Estonia")
        except Exception as exc:
            print(f"Estonia remove error: {exc}")
        
        # Try Sweden via 3x-ui
        try:
            panel = get_sweden_panel()
            if panel and panel.delete_client(client_id):
                removed_any = True
                print(f"Removed client {client_id} from Sweden")
            else:
                # SSH Fallback
                fallback = VPNManager(host=VPS_HOST, port=VPS_PORT, user=VPS_USER, password=VPS_PASSWORD)
                if fallback.remove_user_from_server(client_id):
                    removed_any = True
                    print(f"Removed client {client_id} from Sweden (SSH fallback)")
        except Exception as exc:
            print(f"Sweden remove error: {exc}")
        
        return removed_any

    def restart_server(self):
        client = self._connect()
        try:
            client.exec_command("systemctl restart xray || systemctl restart x-ui")
            return True
        finally:
            client.close()

    def get_server_status(self):
        client = self._connect()
        try:
            stdin, stdout, stderr = client.exec_command("systemctl is-active xray || systemctl is-active x-ui")
            status = stdout.read().decode().strip().splitlines()[0]
            return status == "active"
        finally:
            client.close()
