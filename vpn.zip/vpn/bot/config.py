# Bot configuration
import os

BOT_TOKEN = "8757331587:AAH0PUsD4xV1GIZFMdDg4OJo5aeWJGOEYVE"

# Channel settings
CHANNEL_USERNAME = "@AeroProjectVpn"
CHANNEL_ID = -1003773406536

# Admin settings
ADMIN_USERNAME = "@PavelEndurov"
ADMIN_IDS = [1246190987]

# VPN Server settings - Sweden
VPS_HOST = "2.26.55.143"
VPS_DOMAIN = "2.26.55.143"
VPS_USER = "root"
VPS_PASSWORD = "qwerty1109max"
VPS_PORT = 443
VPS_PUBLIC_KEY = "Ak4cnq8rCd3-5IRa9UvTjSyyjZ2DdF92YBJSr65gdAk"

# 3x-ui Panel Settings - Sweden
VPS_3XUI_PORT = 2053
VPS_3XUI_USERNAME = "admin"
VPS_3XUI_PASSWORD = "admin"

# VPN Server settings - Estonia
VPS2_HOST = "95.85.249.79"
VPS2_DOMAIN = "ee.aeroproject.fun"
VPS2_USER = "root"
VPS2_PASSWORD = "FNvhSI1r4VVdbj7G"
VPS2_PORT = 8443
VPS2_PUBLIC_KEY = "t866kDCHHb2R3aGvwWpyQ1a8UpWXanzY3Pt6LX8Dzw8"

# 3x-ui Panel Settings - Estonia
VPS2_3XUI_PORT = 2053
VPS2_3XUI_USERNAME = "admin"
VPS2_3XUI_PASSWORD = "AeroEE_3xUi!2026"

# VPN Server settings - Germany (NEW)
VPS3_HOST = "2.26.54.63"
VPS3_DOMAIN = "vpn.aeroproject.fun"
VPS3_USER = "root"
VPS3_PASSWORD = "qwerty1109max"
VPS3_PORT = 8444
VPS3_PUBLIC_KEY = "2BSlFrdWjwCLHcGCGkM-Q5yID91AuZhUXKAns7VJOgg"

# 3x-ui Panel Settings - Germany
VPS3_3XUI_PORT = 2053
VPS3_3XUI_USERNAME = "admin"
VPS3_3XUI_PASSWORD = "admin"

# Branding
VPN_NAME = "AeroProjectVPN"
VPN_WEB_URL = "https://vpn.aeroproject.fun"
SUBSCRIPTION_BASE_URL = "https://vpn.aeroproject.fun"

# Pricing
PRICES = {
    "1_month": 100,
    "6_months": 225,
    "1_year": 400,
}

# Trial settings
TRIAL_DAYS = 1

# Database
DB_FILE = os.path.join(os.path.dirname(__file__), "vpn_bot.db")

# MTProto Proxy Settings - Germany
MTPROTO_HOST = "vpn.aeroproject.fun"
MTPROTO_PORT = 8443
MTPROTO_SECRET = "7qFodaCZTu_jDOJZ2X7fNCx2cG4uYWVyb3Byb2plY3QuZnVu"
MTPROTO_TAG = "@AeroProjectVpn"

# CryptoBot
CRYPTO_BOT_TOKEN = "561879:AAGlQg1ZepeCv70Q9CSqr73tbK2Or0289Uv"
