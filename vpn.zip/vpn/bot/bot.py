#!/usr/bin/env python3
"""
VPN Telegram Bot
- Channel subscription check
- Trial access (1 day)
- Purchase options (1 month - 100₽, 6 months - 225₽, 1 year - 400₽)
- VLESS key generation
- Admin panel
"""

import asyncio
import logging
from datetime import datetime, timedelta

from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command, CommandStart
from aiogram.types import CallbackQuery, Message
from aiogram.enums import ParseMode
from aiogram.exceptions import TelegramBadRequest
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiocryptopay import AioCryptoPay, Networks

from config import (
    BOT_TOKEN, CHANNEL_USERNAME, CHANNEL_ID, 
    ADMIN_IDS, ADMIN_USERNAME, PRICES, TRIAL_DAYS,
    VPS_HOST, VPS_PORT, VPS2_HOST, VPS2_USER, VPS2_PASSWORD, VPS2_PORT,
    VPN_NAME, VPN_WEB_URL, CRYPTO_BOT_TOKEN, SUBSCRIPTION_BASE_URL
)
from database import Database
from vpn_manager import VPNManager
from keyboards import (
    main_menu, check_subscription_keyboard, purchase_menu,
    admin_menu, confirm_payment_keyboard, back_button, key_actions
)
from token_crypto import encrypt_user_id, decrypt_token, generate_referral_link

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize bot and dispatcher
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()

# Initialize CryptoPay
cryptopay = AioCryptoPay(token=CRYPTO_BOT_TOKEN, network=Networks.MAIN_NET) if CRYPTO_BOT_TOKEN else None

# Initialize database and VPN manager
db = Database()

# ==================== HELPER FUNCTIONS ====================

def is_admin(user_id: int) -> bool:
    """Check if user is admin."""
    return user_id in ADMIN_IDS


def get_subscription_url(user_id: int) -> str:
    """Return the standard subscription URL."""
    sub_token = encrypt_user_id(user_id)
    return f"{SUBSCRIPTION_BASE_URL}/sub/{sub_token}"


def render_subscription_links(user_id: int, title: str = "Ваша защищенная ссылка подписки") -> str:
    """Render the standard subscription URL."""
    sub_url = get_subscription_url(user_id)
    return (
        f"🛡 <b>{title}:</b>\n"
        f"<code>{sub_url}</code>\n\n"
        f"📋 <i>Нажмите на ссылку, чтобы скопировать</i>"
    )

async def check_user_subscription(user_id: int) -> bool:
    """Check if user is subscribed to channel."""
    try:
        member = await bot.get_chat_member(CHANNEL_ID, user_id)
        return member.status in ['member', 'administrator', 'creator']
    except TelegramBadRequest:
        return False
    except Exception as e:
        logger.error(f"Error checking subscription: {e}")
        return False

def format_time_left(end_date_str):
    """Format time left until subscription ends."""
    if not end_date_str:
        return "♾️ Навсегда"
    try:
        end_date = datetime.fromisoformat(str(end_date_str).replace('Z', '+00:00').replace('+00:00', ''))
        now = datetime.now()
        diff = end_date - now
        
        if diff.days > 365:
            return "♾️ Навсегда"
        elif diff.days > 0:
            hours = diff.seconds // 3600
            return f"📅 {diff.days} дн. {hours} ч."
        elif diff.seconds > 3600:
            return f"⏰ {diff.seconds // 3600} часов"
        elif diff.seconds > 60:
            return f"⏰ {diff.seconds // 60} минут"
        else:
            return "⏰ Менее минуты"
    except:
        return "Неизвестно"

def format_expiry_date(end_date_str):
    """Format expiry date for display."""
    if not end_date_str:
        return "01.01.2099"
    try:
        end_date = datetime.fromisoformat(str(end_date_str).replace('Z', '+00:00').replace('+00:00', ''))
        return end_date.strftime('%d.%m.%Y')
    except:
        return "Неизвестно"

def get_subscription_progress(start_date, end_date):
    """Calculate subscription progress bar."""
    if not start_date or not end_date:
        return "░░░░░░░░░░"
    try:
        start = datetime.fromisoformat(str(start_date).replace('Z', '+00:00').replace('+00:00', ''))
        end = datetime.fromisoformat(str(end_date).replace('Z', '+00:00').replace('+00:00', ''))
        now = datetime.now()
        
        if now >= end:
            return "██████████ Истекла"
        
        total = (end - start).total_seconds()
        elapsed = (now - start).total_seconds()
        progress = min(int((elapsed / total) * 10), 10)
        
        bar = "█" * progress + "░" * (10 - progress)
        return f"{bar}"
    except:
        return "░░░░░░░░░░"

# ==================== HANDLERS ====================

@dp.message(CommandStart())
async def cmd_start(message: Message):
    """Start command handler with referral support."""
    user_id = message.from_user.id
    username = message.from_user.username
    first_name = message.from_user.first_name
    
    # Check if user is blocked
    if db.is_user_blocked(user_id):
        await message.answer(
            "🚫 <b>Ваш аккаунт заблокирован</b>\n\n"
            "Обратитесь к администратору:",
            reply_markup=InlineKeyboardBuilder().button(text="💬 Поддержка", url=f"https://t.me/{ADMIN_USERNAME.replace('@', '')}").as_markup(),
            parse_mode=ParseMode.HTML
        )
        return
    
    # Check for referral in start command
    referrer_id = None
    if message.text and len(message.text.split()) > 1:
        param = message.text.split()[1]
        if param.startswith('ref_'):
            try:
                encrypted_ref = param.replace('ref_', '')
                referrer_id = decrypt_token(encrypted_ref)
            except:
                pass
    
    # Add user to database (with referrer if exists)
    db.add_user(user_id, username, first_name, referrer_id)
    
    # Check subscription
    is_subscribed = await check_user_subscription(user_id)
    
    if not is_subscribed:
        await message.answer(
            f"👋 Привет, {first_name}!\n\n"
            f"🚀 Добро пожаловать в VPN сервис!\n\n"
            f"📢 Для использования бота необходимо подписаться на канал:",
            reply_markup=check_subscription_keyboard(CHANNEL_USERNAME)
        )
        return
    
    # Check if user has active key
    keys = db.get_user_keys(user_id)
    has_active_key = len(keys) > 0
    
    welcome_text = (
        f"👋 Привет, {first_name}!\n\n"
        f"🚀 Добро пожаловать в <b>{VPN_NAME}</b> — твой проводник в свободный интернет!\n\n"
        f"🕵️‍♂️ <b>Наш VPN — это полная анонимность:</b>\n"
        f"• 🚫 Мы <b>не храним логи</b> и историю сайтов\n"
        f"• 🛡 Мощное шифрование (VLESS-Reality) — провайдер не видит, что это VPN\n"
        f"• 👻 Твой реальный IP-адрес скрыт\n\n"
        f"📱 <b>Что умеет бот:</b>\n"
        f"• 🎁 Пробный доступ на 1 день\n"
        f"• 💎 Доступные цены подписки\n"
        f"• 🔑 Быстрая генерация ключей\n"
        f"• 🌍 2 анонимных сервера (Германия + Эстония)\n\n"
        f"💰 <b>Цены:</b>\n"
        f"• 1 месяц — {PRICES['1_month']}₽\n"
        f"• 6 месяцев — {PRICES['6_months']}₽\n"
        f"• 1 год — {PRICES['1_year']}₽\n\n"
        f"💬 По вопросам покупки: {ADMIN_USERNAME}"
    )
    
    user_is_admin = is_admin(user_id)
    await message.answer(welcome_text, reply_markup=main_menu(has_active_key=has_active_key, is_admin=user_is_admin), parse_mode=ParseMode.HTML)

@dp.callback_query(F.data == "check_sub")
async def check_subscription(callback: CallbackQuery):
    """Check subscription callback."""
    user_id = callback.from_user.id
    is_subscribed = await check_user_subscription(user_id)
    
    if is_subscribed:
        keys = db.get_user_keys(user_id)
        has_active_key = len(keys) > 0
        user_is_admin = is_admin(user_id)
        
        await callback.message.edit_text(
            "✅ Подписка подтверждена!\n\n"
            f"🚀 Добро пожаловать в <b>{VPN_NAME}</b>!\n\n"
            "Выберите действие:",
            reply_markup=main_menu(has_active_key=has_active_key, is_admin=user_is_admin),
            parse_mode=ParseMode.HTML
        )
    else:
        await callback.answer(
            "❌ Вы еще не подписались на канал!",
            show_alert=True
        )

@dp.callback_query(F.data == "trial")
async def get_trial(callback: CallbackQuery):
    """Get trial access."""
    user_id = callback.from_user.id
    
    # Check if already used trial
    if db.has_used_trial(user_id):
        await callback.answer("❌ Пробный доступ уже использован!", show_alert=True)
        return
    
    # Check if user has active subscription
    sub = db.get_active_subscription(user_id)
    if sub:
        await callback.answer("❌ У вас уже есть активная подписка!", show_alert=True)
        return
    
    # Show loading message
    loading_msg = await callback.message.edit_text(
        "⏳ <b>Генерация VPN ключа...</b>\n\n"
        "🔧 Создание конфигурации...\n"
        "🌍 Выбор сервера...\n"
        "🔐 Генерация UUID...\n\n"
        "<i>Пожалуйста, подождите...</i>",
        parse_mode=ParseMode.HTML
    )
    
    await asyncio.sleep(2)
    
    # Mark trial as used
    db.set_trial_used(user_id)
    
    # Generate trial key (1 day) - potentially slow (network/SSH/3x-ui)
    try:
        vpn = VPNManager()
        key_data = await asyncio.wait_for(
            asyncio.to_thread(vpn.generate_vpn_key, user_id, TRIAL_DAYS),
            timeout=90,
        )
    except Exception as exc:
        logger.error(f"Trial key generation failed for user {user_id}: {exc}")
        await loading_msg.edit_text(
            "❌ <b>Не удалось выдать ключ</b>\n\n"
            "Сервер сейчас недоступен или перегружен. Попробуйте еще раз через 1-2 минуты.",
            parse_mode=ParseMode.HTML,
        )
        return
    
    # Save to database
    db.add_vpn_key(
        user_id=user_id,
        uuid=key_data['uuid'],
        public_key=key_data['public_key'],
        private_key=key_data['private_key'],
        short_id=key_data['short_id'],
        expires_at=key_data['expires_at'],
        vless_link=key_data['vless_link']
    )
    
    # Add trial subscription record
    db.add_subscription(user_id, "trial", 0, TRIAL_DAYS)
    
    expiry_date = (datetime.now() + timedelta(days=1)).strftime('%d.%m.%Y %H:%M')
    
    await loading_msg.edit_text(
        f"🎁 <b>Пробный доступ активирован!</b>\n\n"
        f"⏰ Срок: 1 день\n"
        f"📅 Истекает: {expiry_date}\n"
        f"🌍 Анонимные серверы: �🇪 Германия + 🇪🇪 Эстония\n"
        f"🛡 Шифрование: VLESS-Reality (без логов)\n"
        f"📱 Устройств: 1/1\n\n"
        f"{render_subscription_links(user_id)}\n\n"
        f"📱 <b>Инструкция для Happ:</b>\n"
        f"1️⃣ Скопируйте ссылку подписки\n"
        f"2️⃣ Откройте Happ → Подписки\n"
        f"3️⃣ + → Вставьте ссылку\n"
        f"4️⃣ Все серверы добавятся автоматически\n\n"
        f"⚠️ <b>Важно:</b> Ссылка работает на 1 устройстве!\n\n"
        f"💰 Для продления пишите: {ADMIN_USERNAME}",
        reply_markup=main_menu(has_active_key=True, is_admin=is_admin(user_id)),
        parse_mode=ParseMode.HTML
    )

@dp.callback_query(F.data == "buy")
async def buy_menu(callback: CallbackQuery):
    """Show purchase menu with balance info."""
    user_id = callback.from_user.id
    balance_info = db.get_user_balance(user_id)
    referral_count = db.get_referral_count(user_id)
    
    balance_text = ""
    if balance_info['balance'] > 0:
        balance_text = f"💰 Ваш баланс: {balance_info['balance']}₽\n"
    if referral_count > 0:
        balance_text += f"👥 Рефералов: {referral_count} (+{referral_count * 6}ч)\n"
    if balance_text:
        balance_text += "\n"
    
    await callback.message.edit_text(
        f"💎 <b>Покупка подписки</b>\n\n"
        f"{balance_text}"
        f"🕵️‍♂️ <b>Наш VPN обеспечивает:</b>\n"
        f"• 🚫 Полное отсутствие логов (No Logs)\n"
        f"• 🛡 Надежное шифрование VLESS-Reality\n"
        f"• 🔒 Защиту от DPI провайдера (трафик маскируется под обычный сайт)\n\n"
        f"🌍 Доступ к 2 анонимным серверам:\n"
        f"�🇪 Германия | 🇪🇪 Эстония\n\n"
        f"📅 <b>1 месяц</b> — {PRICES['1_month']}₽\n"
        f"📅 <b>6 месяцев</b> — {PRICES['6_months']}₽ (выгода 60%)\n"
        f"♾️ <b>1 год</b> — {PRICES['1_year']}₽\n\n"
        f"📱 Включено:\n"
        f"• 1 устройство\n"
        f"• Безлимитный и защищенный трафик\n"
        f"• Поддержка 24/7\n\n"
        f"💬 Для покупки: {ADMIN_USERNAME}\n"
        f"Или выберите тариф ниже:",
        reply_markup=purchase_menu(),
        parse_mode=ParseMode.HTML
    )

@dp.callback_query(F.data.startswith("buy_"))
async def process_purchase(callback: CallbackQuery):
    """Handle purchase selection - show payment method choice."""
    plan = callback.data.replace("buy_", "")
    user_id = callback.from_user.id
    
    price = PRICES.get(plan, 0)
    duration_text = {
        "1_month": "1 месяц",
        "6_months": "6 месяцев",
        "1_year": "1 год"
    }.get(plan, plan)
    
    # Show payment method selection
    kb = InlineKeyboardBuilder()
    if cryptopay:
        kb.button(text="💎 CryptoPay (криптовалюта)", callback_data=f"pay_crypto_{plan}")
    kb.button(text="🇷🇺 Карта РФ", callback_data=f"pay_card_ru_{plan}")
    kb.button(text="🇺🇦 Карта УА (писать в ЛС)", callback_data=f"pay_card_ua_{plan}")
    kb.button(text="◀️ Назад", callback_data="buy")
    kb.adjust(1)
    
    await callback.message.edit_text(
        f"💳 <b>Выбор способа оплаты</b>\n\n"
        f"📋 Тариф: {duration_text}\n"
        f"💰 К оплате: {price}₽\n\n"
        f"Выберите удобный способ:",
        reply_markup=kb.as_markup(),
        parse_mode=ParseMode.HTML
    )

@dp.callback_query(F.data.startswith("pay_crypto_"))
async def pay_with_crypto(callback: CallbackQuery):
    """Process payment via CryptoBot."""
    plan = callback.data.replace("pay_crypto_", "")
    user_id = callback.from_user.id
    username = callback.from_user.username
    
    price = PRICES.get(plan, 0)
    duration_text = {
        "1_month": "1 месяц",
        "6_months": "6 месяцев",
        "1_year": "1 год"
    }.get(plan, plan)
    
    if not cryptopay:
        await callback.answer("CryptoBot не настроен.", show_alert=True)
        return
    
    try:
        invoice = await cryptopay.create_invoice(
            amount=price,
            fiat='RUB',
            currency_type='fiat',
            description=f"Оплата VPN ({duration_text})"
        )
        
        order_id = db.create_order(user_id, username, plan, price, invoice.invoice_id)
        
        kb = InlineKeyboardBuilder()
        kb.button(text="💳 Оплатить", url=invoice.bot_invoice_url)
        kb.button(text="🔄 Проверить оплату", callback_data=f"check_pay_{order_id}")
        kb.button(text="◀️ Назад", callback_data="buy")
        kb.adjust(1)
        
        await callback.message.edit_text(
            f"📦 <b>Оформление заказа</b>\n\n"
            f"📋 Тариф: {duration_text}\n"
            f"💰 К оплате: {price}₽\n\n"
            f"Нажмите кнопку ниже для оплаты через CryptoBot:",
            reply_markup=kb.as_markup(),
            parse_mode=ParseMode.HTML
        )
        
        for admin_id in ADMIN_IDS:
            try:
                await bot.send_message(admin_id, f"⏳ Пользователь @{username or user_id} создал счет на оплату {duration_text} через CryptoBot.", parse_mode=ParseMode.HTML)
            except:
                pass
    except Exception as e:
        logger.error(f"CryptoPay error: {e}")
        await callback.answer("Ошибка создания платежа.", show_alert=True)

@dp.callback_query(F.data.startswith("pay_card_ru_"))
async def pay_with_card_ru(callback: CallbackQuery):
    """Process payment via Russian card."""
    plan = callback.data.replace("pay_card_ru_", "")
    user_id = callback.from_user.id
    username = callback.from_user.username
    
    price = PRICES.get(plan, 0)
    duration_text = {
        "1_month": "1 месяц",
        "6_months": "6 месяцев",
        "1_year": "1 год"
    }.get(plan, plan)
    
    # Create order without invoice_id
    order_id = db.create_order(user_id, username, plan, price)
    
    # Notify admin
    for admin_id in ADMIN_IDS:
        try:
            await bot.send_message(
                admin_id,
                f"🛒 <b>Новый заказ (Карта РФ)!</b>\n\n"
                f"👤 Пользователь: @{username or user_id}\n"
                f"🆔 ID: <code>{user_id}</code>\n"
                f"📦 Тариф: {duration_text}\n"
                f"💰 Сумма: {price}₽\n"
                f"📋 Order ID: {order_id}\n\n"
                f"❗️ Ожидает подтверждения оплаты",
                reply_markup=confirm_payment_keyboard(order_id),
                parse_mode=ParseMode.HTML
            )
        except Exception as e:
            logger.error(f"Failed to notify admin {admin_id}: {e}")
    
    await callback.message.edit_text(
        f"📦 <b>Заказ #{order_id} создан!</b>\n\n"
        f"📋 Тариф: {duration_text}\n"
        f"💰 Сумма: {price}₽\n\n"
        f"💳 <b>Реквизиты для оплаты (Карта РФ):</b>\n"
        f"<code>2204120131636421</code>\n\n"
        f"� После оплаты напишите администратору:\n"
        f"{ADMIN_USERNAME}\n\n"
        f"📋 Укажите Order ID: <code>{order_id}</code>",
        reply_markup=back_button(),
        parse_mode=ParseMode.HTML
    )

@dp.callback_query(F.data.startswith("pay_card_ua_"))
async def pay_with_card_ua(callback: CallbackQuery):
    """Process payment via Ukrainian card."""
    plan = callback.data.replace("pay_card_ua_", "")
    user_id = callback.from_user.id
    username = callback.from_user.username
    
    price = PRICES.get(plan, 0)
    duration_text = {
        "1_month": "1 месяц",
        "6_months": "6 месяцев",
        "1_year": "1 год"
    }.get(plan, plan)
    
    # Create order without invoice_id
    order_id = db.create_order(user_id, username, plan, price)
    
    # Notify admin
    for admin_id in ADMIN_IDS:
        try:
            await bot.send_message(
                admin_id,
                f"� <b>Новый заказ (Карта УА)!</b>\n\n"
                f"👤 Пользователь: @{username or user_id}\n"
                f"🆔 ID: <code>{user_id}</code>\n"
                f"📦 Тариф: {duration_text}\n"
                f"💰 Сумма: {price}₽\n"
                f"📋 Order ID: {order_id}\n\n"
                f"❗️ Ожидает подтверждения оплаты",
                reply_markup=confirm_payment_keyboard(order_id),
                parse_mode=ParseMode.HTML
            )
        except Exception as e:
            logger.error(f"Failed to notify admin {admin_id}: {e}")
    
    await callback.message.edit_text(
        f"📦 <b>Заказ #{order_id} создан!</b>\n\n"
        f"📋 Тариф: {duration_text}\n"
        f"💰 Сумма: {price}₽\n\n"
        f"🇺🇦 <b>Реквизиты для оплаты (Карта УА):</b>\n"
        f"Напишите администратору для получения реквизитов:\n"
        f"{ADMIN_USERNAME}\n\n"
        f"📋 Order ID: <code>{order_id}</code>",
        reply_markup=back_button(),
        parse_mode=ParseMode.HTML
    )

@dp.callback_query(F.data.startswith("check_pay_"))
async def check_crypto_payment(callback: CallbackQuery):
    if not cryptopay:
        await callback.answer("CryptoBot не настроен.", show_alert=True)
        return
        
    order_id = int(callback.data.replace("check_pay_", ""))
    db.cursor.execute("SELECT * FROM orders WHERE id = ?", (order_id,))
    order = db.cursor.fetchone()
    
    if not order or order[5] != 'pending':
        await callback.answer("❌ Заказ не найден или уже оплачен!", show_alert=True)
        return
        
    invoice_id = order[8] # index 8 is invoice_id
    if not invoice_id:
        await callback.answer("❌ Ошибка платежа.", show_alert=True)
        return
        
    try:
        invoices = await cryptopay.get_invoices(invoice_ids=invoice_id)
        if not invoices:
            await callback.answer("Счет не найден.", show_alert=True)
            return
            
        invoice = invoices[0]
        if invoice.status == 'paid':
            await callback.message.edit_text("⏳ Обработка платежа и выдача ключа...")
            
            user_id = order[1]
            duration_type = order[3]
            
            db.mark_order_paid(order_id)
            
            days = None
            if duration_type == "1_month":
                days = 30
            elif duration_type == "6_months":
                days = 180
            
            db.add_subscription(user_id, duration_type, order[4], days)
            
            # Cashback
            user_data = db.get_user(user_id)
            if user_data and user_data[6]:
                cashback = db.add_purchase_cashback(user_data[6], order[4])
                try:
                    await bot.send_message(user_data[6], f"🎉 <b>Кэшбэк получен!</b>\nВаш реферал совершил покупку!\n💰 +{cashback}₽ на баланс", parse_mode=ParseMode.HTML)
                except:
                    pass
            
            vpn = VPNManager()
            key_data = vpn.generate_vpn_key(user_id, days=days)
            
            db.add_vpn_key(
                user_id=user_id,
                uuid=key_data['uuid'],
                public_key=key_data['public_key'],
                private_key=key_data['private_key'],
                short_id=key_data['short_id'],
                expires_at=key_data['expires_at'],
                vless_link=key_data['vless_link'],
                server='multi'
            )
            
            expiry_text = "♾️ Навсегда" if days is None else f"📅 {days} дней"
            await callback.message.edit_text(
                f"✅ <b>Оплата успешно получена!</b>\n\n"
                f"🎉 Тариф: {duration_type}\n"
                f"⏰ Срок: {expiry_text}\n"
                f"🌍 Анонимные серверы: �🇪 Германия + 🇪🇪 Эстония\n\n"
                f"{render_subscription_links(user_id)}\n\n"
                f"📱 Вставьте ссылку в Happ или v2rayNG",
                parse_mode=ParseMode.HTML
            )
            
            for admin_id in ADMIN_IDS:
                try:
                    await bot.send_message(admin_id, f"💰 <b>Новая оплата (CryptoBot)!</b>\nПользователь: @{order[2]}\nСумма: {order[4]}₽", parse_mode=ParseMode.HTML)
                except:
                    pass
        else:
            await callback.answer("⏳ Оплата еще не поступила. Попробуйте через минуту.", show_alert=True)
    except Exception as e:
        logger.error(f"Check payment error: {e}")
        await callback.answer("Ошибка при проверке платежа.", show_alert=True)

@dp.callback_query(F.data == "my_key")
async def show_my_key(callback: CallbackQuery):
    """Show user's active key."""
    user_id = callback.from_user.id
    keys = db.get_user_keys(user_id)
    sub = db.get_active_subscription(user_id)
    
    if not keys:
        await callback.message.edit_text(
            f"🚨 <b>{VPN_NAME}</b>\n\n"
            f"⏳ <b>Подписка истекла</b>\n\n"
            f"🎁 Получите пробный доступ\n"
            f"💎 Или купите подписку",
            reply_markup=main_menu(has_active_key=False, is_admin=is_admin(user_id)),
            parse_mode=ParseMode.HTML
        )
        return
    
    key = keys[0]
    vless_link = key[9]
    expires_at = key[7]
    created_at = key[6] if len(key) > 6 else None
    
    time_left = format_time_left(expires_at)
    expiry_date = format_expiry_date(expires_at)
    progress_bar = get_subscription_progress(created_at, expires_at)
    
    if "Истекла" in progress_bar:
        await callback.message.edit_text(
            f"🚨 <b>{VPN_NAME}</b>\n\n"
            f"⏳ <b>Подписка истекла</b>\n"
            f"📅 {expiry_date}\n\n"
            f"💎 Продлить подписку?",
            reply_markup=main_menu(has_active_key=False, is_admin=is_admin(user_id)),
            parse_mode=ParseMode.HTML
        )
        return
    
    await callback.message.edit_text(
        f"🔥 <b>{VPN_NAME}</b>\n\n"
        f"{progress_bar}\n"
        f"⏰ Осталось: {time_left}\n"
        f"📅 Истекает: {expiry_date}\n"
        f"🌍 Анонимные серверы: �🇪 Германия + 🇪🇪 Эстония\n"
        f"🛡 Шифрование: VLESS-Reality (без логов)\n"
        f"📱 Устройств: 1/1\n\n"
        f"{render_subscription_links(user_id)}\n\n"
        f"📱 <b>Инструкция для Happ:</b>\n"
        f"1️⃣ Скопируйте ссылку подписки\n"
        f"2️⃣ Откройте Happ → Подписки\n"
        f"3️⃣ Вставьте ссылку → Все серверы добавятся",
        reply_markup=key_actions(),
        parse_mode=ParseMode.HTML
    )

@dp.callback_query(F.data == "copy_key")
async def copy_key(callback: CallbackQuery):
    """Just acknowledge the copy action."""
    await callback.answer("✅ Ключ скопирован! Вставьте в приложение.", show_alert=True)

@dp.callback_query(F.data == "renew_key")
async def renew_key(callback: CallbackQuery):
    """Generate new key (for paid users)."""
    user_id = callback.from_user.id
    sub = db.get_active_subscription(user_id)
    
    if not sub:
        await callback.answer("❌ У вас нет активной подписки!", show_alert=True)
        return
    
    # Get subscription duration
    duration_type = sub[4]
    days = 365 if duration_type == "1_year" else 30
    if duration_type == "6_months":
        days = 180
    elif duration_type == "1_month":
        days = 30
    
    # Show loading
    loading_msg = await callback.message.edit_text(
        "🔄 <b>Обновление ключа...</b>\n\n"
        "⏳ Генерация новой конфигурации...\n\n"
        "<i>Пожалуйста, подождите...</i>",
        parse_mode=ParseMode.HTML
    )
    
    await asyncio.sleep(1.5)
    
    # Generate new key
    vpn = VPNManager()
    key_data = vpn.generate_vpn_key(user_id, days=days)
    
    # Save to database with server
    db.add_vpn_key(
        user_id=user_id,
        uuid=key_data['uuid'],
        public_key=key_data['public_key'],
        private_key=key_data['private_key'],
        short_id=key_data['short_id'],
        expires_at=key_data['expires_at'],
        vless_link=key_data['vless_link'],
        server='germany'
    )
    
    await loading_msg.edit_text(
        f"🔄 <b>Ссылка обновлена!</b>\n\n"
        f"{render_subscription_links(user_id, 'Новые ссылки подписки')}\n\n"
        f"⚠️ <b>Важно:</b> Обновите ссылку в Happ!\n"
        f"📱 Старая ссылка больше не действительна",
        reply_markup=key_actions(),
        parse_mode=ParseMode.HTML
    )

@dp.callback_query(F.data == "help")
async def show_help(callback: CallbackQuery):
    """Show help/instructions."""
    await callback.message.edit_text(
        f"📱 <b>Инструкция по подключению</b>\n\n"
        f"<b>Windows (Nekoray):</b>\n"
        f"1️⃣ Скачайте с github.com/MatsuriDayo/nekoray\n"
        f"2️⃣ ПКМ в окне → Добавить профиль из буфера\n"
        f"3️⃣ Выберите сервер → Подключить\n\n"
        f"<b>Android (v2rayNG):</b>\n"
        f"1️⃣ Установите из Google Play\n"
        f"2️⃣ + → Импорт из буфера обмена\n"
        f"3️⃣ Тап на профиль → Подключить\n\n"
        f"<b>iOS (Streisand/Happ):</b>\n"
        f"1️⃣ Установите из App Store\n"
        f"2️⃣ + → Импорт из буфера\n"
        f"3️⃣ Подключить\n\n"
        f"⚠️ <b>Важно:</b> 1 ключ = 1 устройство\n\n"
        f"💬 Проблемы? Пишите: {ADMIN_USERNAME}",
        reply_markup=back_button(),
        parse_mode=ParseMode.HTML
    )

@dp.callback_query(F.data == "back_to_main")
async def back_to_main(callback: CallbackQuery):
    """Return to main menu."""
    user_id = callback.from_user.id
    keys = db.get_user_keys(user_id)
    has_active_key = len(keys) > 0
    
    welcome_text = (
        f"🚀 <b>{VPN_NAME}</b> — твой анонимный проводник в свободный интернет!\n\n"
        f"🕵️‍♂️ <b>Наша защита:</b>\n"
        f"• 🚫 Без логов и слежки\n"
        f"• 🛡 VLESS-Reality шифрование\n"
        f"• 👻 Полная скрытность от провайдера\n\n"
        f"📱 <b>Возможности:</b>\n"
        f"• 🎁 Пробный доступ на 1 день\n"
        f"• 💎 Доступные цены\n"
        f"• 🔑 Быстрая генерация ключей\n"
        f"• 🌍 2 защищенных сервера (Германия + Эстония)\n\n"
        f"💰 <b>Цены:</b>\n"
        f"• 1 месяц — {PRICES['1_month']}₽\n"
        f"• 6 месяцев — {PRICES['6_months']}₽\n"
        f"• 1 год — {PRICES['1_year']}₽\n\n"
        f"💬 По вопросам: {ADMIN_USERNAME}"
    )
    
    user_is_admin = is_admin(user_id)
    await callback.message.edit_text(welcome_text, reply_markup=main_menu(has_active_key=has_active_key, is_admin=user_is_admin), parse_mode=ParseMode.HTML)

@dp.callback_query(F.data == "admin_panel")
async def admin_panel_callback(callback: CallbackQuery):
    """Admin panel from callback."""
    if not is_admin(callback.from_user.id):
        await callback.answer("❌ У вас нет доступа!", show_alert=True)
        return
    
    await callback.message.edit_text(
        "🔐 <b>Админ панель</b>\n\n"
        f"🤖 Бот: @{VPN_NAME}_bot\n"
        f"🌍 Серверов: 2\n\n"
        "Выберите действие:",
        reply_markup=admin_menu(),
        parse_mode=ParseMode.HTML
    )

@dp.message(Command("admin"))
async def admin_panel_command(message: Message):
    """Admin panel access via command."""
    if not is_admin(message.from_user.id):
        await message.answer("❌ У вас нет доступа!")
        return
    
    await message.answer(
        "🔐 <b>Админ панель</b>\n\n"
        f"🤖 Бот: @{VPN_NAME}_bot\n"
        f"🌍 Серверов: 2\n\n"
        "Выберите действие:",
        reply_markup=admin_menu(),
        parse_mode=ParseMode.HTML
    )

@dp.callback_query(F.data == "admin_stats")
async def admin_stats(callback: CallbackQuery):
    """Show bot statistics."""
    if not is_admin(callback.from_user.id):
        await callback.answer("❌ Нет доступа!", show_alert=True)
        return
    
    stats = db.get_stats()
    vpn1 = VPNManager()
    vpn2 = VPNManager(host=VPS2_HOST, port=VPS2_PORT, user=VPS2_USER, password=VPS2_PASSWORD)
    
    server1_status = vpn1.get_server_status()
    server2_status = vpn2.get_server_status()
    
    await callback.message.edit_text(
        f"📊 <b>Статистика {VPN_NAME}</b>\n\n"
        f"👥 Всего пользователей: {stats['total_users']}\n"
        f"💎 Активных подписок: {stats['active_subs']}\n"
        f"🔑 Активных ключей: {stats['active_keys']}\n\n"
        f"🖥 Серверы:\n"
        f"🇸🇪 Швеция: {'✅' if server1_status else '❌'}\n"
        f"🇪🇪 Эстония: {'✅' if server2_status else '❌'}\n\n"
        f"📅 {datetime.now().strftime('%d.%m.%Y %H:%M')}",
        reply_markup=admin_menu(),
        parse_mode=ParseMode.HTML
    )

@dp.callback_query(F.data.startswith("confirm_pay_"))
async def confirm_payment(callback: CallbackQuery):
    """Confirm payment and generate key."""
    if not is_admin(callback.from_user.id):
        await callback.answer("❌ Нет доступа!", show_alert=True)
        return
    
    order_id = int(callback.data.replace("confirm_pay_", ""))
    
    # Get order info
    db.cursor.execute("SELECT * FROM orders WHERE id = ?", (order_id,))
    order = db.cursor.fetchone()
    
    if not order or order[5] != 'pending':
        await callback.answer("❌ Заказ не найден или уже обработан!", show_alert=True)
        return
    
    user_id = order[1]
    duration_type = order[3]
    
    # Calculate days
    days = 365  # 1 year
    if duration_type == "1_month":
        days = 30
    elif duration_type == "6_months":
        days = 180
    
    # Mark order as paid
    db.mark_order_paid(order_id)
    
    # Add subscription
    db.add_subscription(user_id, duration_type, order[4], days)
    
    # Add cashback to referrer (2% of purchase)
    user_data = db.get_user(user_id)
    if user_data and user_data[6]:  # referrer_id
        cashback = db.add_purchase_cashback(user_data[6], order[4])
        try:
            await bot.send_message(
                user_data[6],
                f"🎉 <b>Кэшбэк получен!</b>\n\n"
                f"Ваш реферал совершил покупку!\n"
                f"💰 +{cashback}₽ на ваш баланс\n"
                f"👥 Приглашайте еще друзей!",
                parse_mode=ParseMode.HTML
            )
        except:
            pass
    
    # Generate key - use Germany server
    vpn = VPNManager()
    key_data = vpn.generate_vpn_key(user_id, days=days)
    
    # Save key with server info
    db.add_vpn_key(
        user_id=user_id,
        uuid=key_data['uuid'],
        public_key=key_data['public_key'],
        private_key=key_data['private_key'],
        short_id=key_data['short_id'],
        expires_at=key_data['expires_at'],
        vless_link=key_data['vless_link'],
        server='germany'
    )
    
    expiry_text = "♾️ Навсегда" if days is None else f"📅 {days} дней"
    
    # Notify user
    try:
        await bot.send_message(
            user_id,
            f"✅ <b>Оплата подтверждена!</b>\n\n"
            f"🎉 Заказ #{order_id} оплачен\n"
            f"⏰ Срок: {expiry_text}\n"
            f"🌍 Серверы: 🇸🇪 Швеция + 🇪🇪 Эстония\n\n"
            f"{render_subscription_links(user_id, 'Ваши ссылки подписки')}\n\n"
            f"📱 Добавьте в Happ для автоматического обновления\n"
            f"💎 Спасибо за покупку!",
            parse_mode=ParseMode.HTML
        )
    except Exception as e:
        logger.error(f"Failed to notify user {user_id}: {e}")
    
    await callback.message.edit_text(
        f"✅ Оплата подтверждена!\n"
        f"🔑 Ключ отправлен пользователю <code>{user_id}</code>",
        parse_mode=ParseMode.HTML
    )

@dp.callback_query(F.data.startswith("reject_pay_"))
async def reject_payment(callback: CallbackQuery):
    """Reject payment."""
    if not is_admin(callback.from_user.id):
        await callback.answer("❌ Нет доступа!", show_alert=True)
        return
    
    order_id = int(callback.data.replace("reject_pay_", ""))
    
    # Get order info for user notification
    db.cursor.execute("SELECT user_id FROM orders WHERE id = ?", (order_id,))
    result = db.cursor.fetchone()
    
    # Update order status
    db.cursor.execute("UPDATE orders SET status = 'rejected' WHERE id = ?", (order_id,))
    db.conn.commit()
    
    # Notify user
    if result:
        try:
            await bot.send_message(
                result[0],
                f"❌ <b>Заказ #{order_id} отклонен</b>\n\n"
                f"Пожалуйста, свяжитесь с {ADMIN_USERNAME}",
                parse_mode=ParseMode.HTML
            )
        except:
            pass
    
    await callback.message.edit_text("❌ Заказ отклонен")

@dp.callback_query(F.data == "admin_orders")
async def admin_orders(callback: CallbackQuery):
    """Show pending orders."""
    if not is_admin(callback.from_user.id):
        await callback.answer("❌ Нет доступа!", show_alert=True)
        return
    
    orders = db.get_pending_orders()
    
    if not orders:
        await callback.message.edit_text(
            "📋 Нет ожидающих заказов",
            reply_markup=admin_menu()
        )
        return
    
    text = "📋 <b>Ожидающие заказы:</b>\n\n"
    for order in orders:
        username = order[2] if order[2] else "Нет username"
        text += f"🆔 #{order[0]} | @{username} | {order[3]} | {order[4]}₽\n"
    
    await callback.message.edit_text(text, reply_markup=admin_menu(), parse_mode=ParseMode.HTML)

@dp.callback_query(F.data == "admin_restart")
async def admin_restart(callback: CallbackQuery):
    """Restart VPN server."""
    if not is_admin(callback.from_user.id):
        await callback.answer("❌ Нет доступа!", show_alert=True)
        return
    
    vpn = VPNManager()
    vpn.restart_server()
    
    await callback.answer("🔄 Сервер перезагружен!", show_alert=True)

@dp.callback_query(F.data == "admin_users")
async def admin_users(callback: CallbackQuery):
    """Show users list."""
    if not is_admin(callback.from_user.id):
        await callback.answer("❌ Нет доступа!", show_alert=True)
        return
    
    users = db.get_all_users()
    
    text = f"👥 <b>Всего пользователей: {len(users)}</b>\n\n"
    text += "Последние 10:\n"
    
    for user in users[-10:]:
        username = user[1] if user[1] else "Нет username"
        text += f"• @{username} (ID: <code>{user[0]}</code>)\n"
    
    await callback.message.edit_text(text, reply_markup=admin_menu(), parse_mode=ParseMode.HTML)

@dp.callback_query(F.data == "admin_keys")
async def admin_keys(callback: CallbackQuery):
    """Show all active keys."""
    if not is_admin(callback.from_user.id):
        await callback.answer("❌ Нет доступа!", show_alert=True)
        return
    
    db.cursor.execute("SELECT COUNT(*) FROM vpn_keys WHERE is_active = 1")
    count = db.cursor.fetchone()[0]
    
    await callback.message.edit_text(
        f"🔑 <b>Активных ключей: {count}</b>\n\n"
        f"📊 В базе данных: {count} ключей",
        reply_markup=admin_menu(),
        parse_mode=ParseMode.HTML
    )

@dp.message(Command("block"))
async def block_user_cmd(message: Message):
    """Block user by admin. Usage: /block USER_ID"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ У вас нет доступа!")
        return
    
    args = message.text.split()
    if len(args) != 2:
        await message.answer("❌ Использование: <code>/block USER_ID</code>", parse_mode=ParseMode.HTML)
        return
    
    try:
        user_id = int(args[1])
        db.block_user(user_id)
        
        # Remove user from both servers
        try:
            vpn1 = VPNManager()
            vpn2 = VPNManager(host=VPS2_HOST, port=VPS2_PORT, user=VPS2_USER, password=VPS2_PASSWORD)
            
            # Get user UUIDs and remove from servers
            keys = db.cursor.execute("SELECT uuid FROM vpn_keys WHERE user_id = ?", (user_id,)).fetchall()
            for key in keys:
                uuid = key[0]
                vpn1.remove_user_from_server(uuid)
                vpn2.remove_user_from_server(uuid)
        except Exception as e:
            logger.error(f"Error removing user from servers: {e}")
        
        await message.answer(f"✅ Пользователь <code>{user_id}</code> заблокирован и удален с серверов.", parse_mode=ParseMode.HTML)
    except ValueError:
        await message.answer("❌ USER_ID должен быть числом!")
    except Exception as e:
        await message.answer(f"❌ Ошибка: {e}")

@dp.message(Command("unblock"))
async def unblock_user_cmd(message: Message):
    """Unblock user by admin. Usage: /unblock USER_ID"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ У вас нет доступа!")
        return
    
    args = message.text.split()
    if len(args) != 2:
        await message.answer("❌ Использование: <code>/unblock USER_ID</code>", parse_mode=ParseMode.HTML)
        return
    
    try:
        user_id = int(args[1])
        db.unblock_user(user_id)
        await message.answer(f"✅ Пользователь <code>{user_id}</code> разблокирован.</code>", parse_mode=ParseMode.HTML)
    except ValueError:
        await message.answer("❌ USER_ID должен быть числом!")
    except Exception as e:
        await message.answer(f"❌ Ошибка: {e}")

@dp.message(Command("blocked"))
async def list_blocked_cmd(message: Message):
    """List blocked users."""
    if not is_admin(message.from_user.id):
        await message.answer("❌ У вас нет доступа!")
        return
    
    blocked = db.get_blocked_users()
    
    if not blocked:
        await message.answer("✅ Нет заблокированных пользователей.")
        return
    
    text = f"🚫 <b>Заблокированные пользователи ({len(blocked)}):</b>\n\n"
    for user in blocked:
        username = user[1] if user[1] else "Нет username"
        text += f"• ID: <code>{user[0]}</code> | @{username}\n"
    
    await message.answer(text, parse_mode=ParseMode.HTML)

@dp.message(Command("ref"))
async def referral_cmd(message: Message):
    """Show referral link and stats."""
    user_id = message.from_user.id
    
    # Generate referral link
    ref_link = generate_referral_link(user_id)
    
    # Get stats
    balance_info = db.get_user_balance(user_id)
    referral_count = db.get_referral_count(user_id)
    
    text = (
        f"🎁 <b>Реферальная программа</b>\n\n"
        f"🔗 <b>Ваша ссылка:</b>\n"
        f"<code>{ref_link}</code>\n\n"
        f"📊 <b>Статистика:</b>\n"
        f"👥 Приглашено: {referral_count}\n"
        f"⏰ Бонусные часы: +{balance_info['bonus_hours']}ч\n"
        f"💰 Баланс: {balance_info['balance']}₽\n\n"
        f"🎁 <b>Награды:</b>\n"
        f"• +6 часов VPN за каждого друга\n"
        f"• +2% с каждой покупки реферала\n\n"
        f"📱 Поделитесь ссылкой с друзьями!"
    )
    
    await message.answer(text, parse_mode=ParseMode.HTML)

# ==================== BROADCAST ====================

@dp.message(Command("all"))
async def broadcast_cmd(message: Message):
    """Broadcast message to all users. Usage: /all message"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ У вас нет доступа!")
        return
    
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        await message.answer("❌ Использование: <code>/all текст сообщения</code>", parse_mode=ParseMode.HTML)
        return
    
    broadcast_text = args[1]
    user_ids = db.get_all_user_ids()
    
    sent = 0
    failed = 0
    
    status_msg = await message.answer(f"📢 Рассылка начата...\n👥 Получателей: {len(user_ids)}")
    
    for user_id in user_ids:
        try:
            await bot.send_message(
                user_id,
                f"📢 <b>Сообщение от администрации:</b>\n\n{broadcast_text}",
                parse_mode=ParseMode.HTML
            )
            sent += 1
        except Exception as e:
            logger.error(f"Failed to send broadcast to {user_id}: {e}")
            failed += 1
        await asyncio.sleep(0.05)  # Rate limit protection
    
    await status_msg.edit_text(
        f"✅ <b>Рассылка завершена!</b>\n\n"
        f"📤 Отправлено: {sent}\n"
        f"❌ Ошибок: {failed}",
        parse_mode=ParseMode.HTML
    )

@dp.callback_query(F.data == "admin_broadcast")
async def admin_broadcast_callback(callback: CallbackQuery):
    """Prompt admin to use /all command."""
    if not is_admin(callback.from_user.id):
        await callback.answer("❌ Нет доступа!", show_alert=True)
        return
    
    await callback.message.edit_text(
        f"📢 <b>Массовая рассылка</b>\n\n"
        f"Используйте команду:\n"
        f"<code>/all текст сообщения</code>\n\n"
        f"Пример:\n"
        f"<code>/all Привет всем! Новые цены на VPN!</code>",
        reply_markup=admin_menu(),
        parse_mode=ParseMode.HTML
    )

# ==================== EXPIRED KEYS CLEANUP ====================

async def cleanup_expired_keys():
    """Background task to remove expired keys from servers."""
    while True:
        try:
            await asyncio.sleep(600)  # Check every 10 minutes
            expired_keys = db.get_expired_keys()
            if expired_keys:
                logger.info(f"Found {len(expired_keys)} expired keys to cleanup")
                for key in expired_keys:
                    try:
                        key_id = key[0]
                        client_uuid = key[2]
                        user_id = key[1]
                        # Remove from servers
                        vpn_manager = VPNManager()
                        vpn_manager.remove_key_from_all_servers(client_uuid)
                        # Deactivate in DB
                        db.deactivate_key(key_id)
                        logger.info(f"Deactivated expired key {key_id} for user {user_id}")
                    except Exception as exc:
                        logger.error(f"Error cleaning up key {key_id}: {exc}")
        except Exception as exc:
            logger.error(f"Cleanup task error: {exc}")
            await asyncio.sleep(60)

# ==================== MAIN ====================

async def main():
    """Start the bot."""
    logger.info(f"Starting {VPN_NAME} bot...")
    # Start background cleanup task
    asyncio.create_task(cleanup_expired_keys())
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
