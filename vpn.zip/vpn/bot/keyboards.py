from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder

# Main menu keyboard
def main_menu(has_active_key=False, is_admin=False):
    builder = InlineKeyboardBuilder()
    
    if not has_active_key:
        builder.button(text="🎁 Пробный доступ (1 день)", callback_data="trial")
    
    builder.button(text="💎 Купить подписку", callback_data="buy")
    builder.button(text="🔑 Мой ключ", callback_data="my_key")
    builder.button(text="📱 Инструкция", callback_data="help")
    
    if is_admin:
        builder.button(text="🔐 Админ панель", callback_data="admin_panel")
    
    builder.button(text="💬 Поддержка", url="https://t.me/PavelEndurov")
    
    if is_admin:
        builder.adjust(1, 2, 2, 1)
    else:
        builder.adjust(1, 2, 2)
    return builder.as_markup()

# Subscription check keyboard
def check_subscription_keyboard(channel_username):
    builder = InlineKeyboardBuilder()
    builder.button(text="📢 Подписаться на канал", url=f"https://t.me/{channel_username.replace('@', '')}")
    builder.button(text="✅ Я подписался", callback_data="check_sub")
    builder.adjust(1)
    return builder.as_markup()

# Purchase menu keyboard
def purchase_menu():
    builder = InlineKeyboardBuilder()
    builder.button(text="📅 1 месяц — 100₽", callback_data="buy_1_month")
    builder.button(text="📅 6 месяцев — 225₽", callback_data="buy_6_months")
    builder.button(text="♾️ 1 год — 400₽", callback_data="buy_1_year")
    builder.button(text="🔙 Назад", callback_data="back_to_main")
    builder.adjust(1)
    return builder.as_markup()

# Admin keyboard
def admin_menu():
    builder = InlineKeyboardBuilder()
    builder.button(text="📊 Статистика", callback_data="admin_stats")
    builder.button(text="👥 Пользователи", callback_data="admin_users")
    builder.button(text="🔑 Все ключи", callback_data="admin_keys")
    builder.button(text="📋 Заказы", callback_data="admin_orders")
    builder.button(text="📢 Рассылка /all", callback_data="admin_broadcast")
    builder.button(text="🔄 Перезагрузить сервер", callback_data="admin_restart")
    builder.button(text="🔙 Назад", callback_data="back_to_main")
    builder.adjust(2, 2, 2, 1)
    return builder.as_markup()

# Confirm payment keyboard (for admin)
def confirm_payment_keyboard(order_id):
    builder = InlineKeyboardBuilder()
    builder.button(text="✅ Подтвердить оплату", callback_data=f"confirm_pay_{order_id}")
    builder.button(text="❌ Отклонить", callback_data=f"reject_pay_{order_id}")
    builder.adjust(2)
    return builder.as_markup()

# Back button
def back_button(callback_data="back_to_main"):
    builder = InlineKeyboardBuilder()
    builder.button(text="🔙 Назад", callback_data=callback_data)
    return builder.as_markup()

# Key actions keyboard
def key_actions():
    builder = InlineKeyboardBuilder()
    builder.button(text="📋 Копировать ключ", callback_data="copy_key")
    builder.button(text="🔄 Обновить ключ", callback_data="renew_key")
    builder.button(text="🔙 Назад", callback_data="back_to_main")
    builder.adjust(2, 1)
    return builder.as_markup()
