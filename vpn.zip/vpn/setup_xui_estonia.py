import paramiko
import time

print("Connecting to Estonia...")
client = paramiko.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect('95.85.249.79', username='root', password='FNvhSI1r4VVdbj7G', timeout=30)

print("Downloading installer...")
stdin, stdout, stderr = client.exec_command('curl -Lso /tmp/xui.sh https://raw.githubusercontent.com/mhsanaei/3x-ui/master/install.sh')
stdout.channel.recv_exit_status()

print("Running installer (this takes 1-2 minutes)...")
stdin, stdout, stderr = client.exec_command('bash /tmp/xui.sh', timeout=180)

# Send 'y' responses
for i in range(3):
    time.sleep(3)
    stdin.write('y\n')
    stdin.flush()
    print(f"Sent response {i+1}/3")

# Wait for completion
exit_code = stdout.channel.recv_exit_status()
print(f"Install exit code: {exit_code}")

# Check status
time.sleep(2)
stdin, stdout, stderr = client.exec_command('systemctl is-active x-ui')
status = stdout.read().decode().strip()
print(f"3x-ui status: {status}")

# If not active, try to start
if status != 'active':
    print("Trying to start...")
    client.exec_command('systemctl start x-ui')
    time.sleep(2)
    stdin, stdout, stderr = client.exec_command('systemctl is-active x-ui')
    print(f"After start: {stdout.read().decode().strip()}")

client.close()
print("Done!")
