import paramiko
import sys

sys.stdout.reconfigure(encoding='utf-8')

# Sweden server
HOST1 = "64.188.81.198"
# Estonia server  
HOST2 = "95.85.249.79"
USER = "root"
PASSWORD1 = "rqrecBUtBVNcKKX5"
PASSWORD2 = "FNvhSI1r4VVdbj7G"

def check_server(host, password, name):
    print(f"\n{'='*50}")
    print(f"Checking {name} ({host})...")
    print('='*50)
    
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(host, username=USER, password=password, timeout=30)
    
    # Check XRay status
    stdin, stdout, stderr = client.exec_command("systemctl status xray --no-pager 2>/dev/null || service xray status 2>/dev/null || ps aux | grep xray | grep -v grep")
    print("\n📊 XRay Status:")
    print(stdout.read().decode()[:500])
    
    # Check resources
    stdin, stdout, stderr = client.exec_command("free -h && echo '---' && df -h / && echo '---' && uptime")
    print("\n💾 Resources:")
    print(stdout.read().decode())
    
    # Check XRay config for MTU
    stdin, stdout, stderr = client.exec_command("cat /usr/local/etc/xray/config.json 2>/dev/null || cat /etc/xray/config.json 2>/dev/null || find / -name 'config.json' -path '*xray*' 2>/dev/null | head -1 | xargs cat 2>/dev/null")
    config = stdout.read().decode()
    if config and len(config) > 10:
        print("\n⚙️  XRay Config exists (checking MTU settings...)")
        if '"mtu"' in config:
            # Extract MTU value
            import re
            mtu_match = re.search(r'"mtu"[:\s]+(\d+)', config)
            if mtu_match:
                print(f"   Current MTU: {mtu_match.group(1)}")
        else:
            print("   ⚠️  MTU not set in config (may cause mobile issues)")
    else:
        print("\n❌ XRay config not found!")
    
    # Check network interfaces MTU
    stdin, stdout, stderr = client.exec_command("ip link show | grep mtu")
    print("\n🌐 Interface MTU:")
    print(stdout.read().decode())
    
    # Check XRay logs for errors
    stdin, stdout, stderr = client.exec_command("journalctl -u xray --no-pager -n 50 2>/dev/null | tail -30 || cat /var/log/xray/error.log 2>/dev/null | tail -30 || cat /var/log/xray/access.log 2>/dev/null | tail -20")
    logs = stdout.read().decode()
    if logs.strip():
        print("\n📝 XRay Logs (last 30 lines):")
        print(logs[:1500])
    
    # Check if any rate limiting
    stdin, stdout, stderr = client.exec_command("tc qdisc show 2>/dev/null | head -5 || echo 'No traffic control rules'")
    tc = stdout.read().decode()
    if 'No traffic control' not in tc:
        print("\n🚦 Traffic Control:")
        print(tc)
    
    # Check connection count
    stdin, stdout, stderr = client.exec_command("ss -tuln | grep -E ':(443|80|8080|8443)' | wc -l && ss -tuln | grep -E ':(443|80|8080|8443)'")
    print("\n🔌 Listening ports:")
    print(stdout.read().decode())
    
    client.close()
    print(f"\n✅ {name} check complete")

# Check both servers
check_server(HOST1, PASSWORD1, "🇸🇪 Sweden Server")
check_server(HOST2, PASSWORD2, "🇪🇪 Estonia Server")

print("\n" + "="*50)
print("Analysis complete!")
print("="*50)
