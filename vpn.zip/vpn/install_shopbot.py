import paramiko
import time
import sys

sys.stdout.reconfigure(encoding='utf-8')

servers = [
    {"name": "Sweden", "ip": "64.188.81.198", "user": "root", "pass": "rqrecBUtBVNcKKX5", "is_main": True},
    {"name": "Estonia", "ip": "95.85.249.79", "user": "root", "pass": "FNvhSI1r4VVdbj7G", "is_main": False}
]

DOMAIN = "64.188.81.198.nip.io"
EMAIL = "admin@aeroprojectvpn.com"

def run_cmd(client, cmd, print_output=True):
    stdin, stdout, stderr = client.exec_command(cmd)
    out = stdout.read().decode('utf-8', errors='replace').strip()
    err = stderr.read().decode('utf-8', errors='replace').strip()
    if print_output and out:
        print(out)
    if print_output and err:
        print(f"Error/Warning: {err}")
    return stdout.channel.recv_exit_status(), out, err

for s in servers:
    print(f"\n==================== Setup {s['name']} ({s['ip']}) ====================")
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(s['ip'], username=s['user'], password=s['pass'], timeout=30)
        
        print("1. Stopping old services...")
        run_cmd(client, "systemctl stop xray && systemctl disable xray")
        if s['is_main']:
            run_cmd(client, "pkill -f 'python3 bot.py'")
            run_cmd(client, "pkill -f 'python3 subscription_api.py'")
            run_cmd(client, "systemctl stop caddy && systemctl disable caddy")
            
        print("2. Installing 3x-ui...")
        # Auto-install 3x-ui with username: admin, password: admin, port: 2053
        install_3xui_cmd = 'printf "y\\nadmin\\nadmin\\n2053\\n" | bash <(curl -Ls https://raw.githubusercontent.com/mhsanaei/3x-ui/master/install.sh)'
        run_cmd(client, install_3xui_cmd)
        
        # Ensure 3x-ui is running
        run_cmd(client, "systemctl enable x-ui && systemctl start x-ui")
        
        if s['is_main']:
            print("3. Installing vless-shopbot dependencies...")
            run_cmd(client, "apt-get update && apt-get install -y git docker.io docker-compose nginx certbot python3-certbot-nginx")
            
            print("4. Setting up vless-shopbot repo...")
            run_cmd(client, "rm -rf /root/vless-shopbot")
            run_cmd(client, "git clone https://github.com/evansvl/vless-shopbot.git /root/vless-shopbot")
            
            print("5. Getting SSL cert for Nginx...")
            # Make sure port 80 is free
            run_cmd(client, "systemctl stop nginx")
            certbot_cmd = f"certbot certonly --standalone -d {DOMAIN} --email {EMAIL} --agree-tos --non-interactive"
            run_cmd(client, certbot_cmd)
            
            print("6. Configuring Nginx...")
            nginx_conf = f"""
server {{
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name {DOMAIN};

    ssl_certificate /etc/letsencrypt/live/{DOMAIN}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/{DOMAIN}/privkey.pem;

    location / {{
        proxy_pass http://127.0.0.1:1488;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }}
}}
"""
            # Write nginx config
            # Use echo with base64 to avoid quoting issues
            import base64
            b64_conf = base64.b64encode(nginx_conf.encode()).decode()
            run_cmd(client, f"echo {b64_conf} | base64 -d > /etc/nginx/sites-available/vless-shopbot.conf")
            run_cmd(client, "rm -f /etc/nginx/sites-enabled/default")
            run_cmd(client, "ln -sf /etc/nginx/sites-available/vless-shopbot.conf /etc/nginx/sites-enabled/")
            
            print("7. Starting Nginx and Docker Compose...")
            run_cmd(client, "systemctl start nginx && systemctl enable nginx")
            run_cmd(client, "systemctl reload nginx")
            run_cmd(client, "cd /root/vless-shopbot && docker-compose up -d --build")
            
        client.close()
        print("Done!")
    except Exception as e:
        print(f"Error on {s['name']}: {e}")
