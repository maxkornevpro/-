#!/bin/bash
pm2 delete subscription-api 2>/dev/null
sleep 1
cd /opt/aeroprojectvpn
pm2 start subscription_api.py --name subscription-api --interpreter python3
sleep 3
echo "=== PM2 ==="
pm2 show subscription-api 2>/dev/null | grep -E "status|pid|uptime|memory"
echo "=== PORT ==="
ss -tlnp | grep 8080 || echo "no port 8080"
echo "=== LOCAL TEST ==="
curl -s http://127.0.0.1:8080/ 2>/dev/null | head -1 || echo "curl fail"
echo "=== NGINX TEST ==="
curl -sk https://aeroproject.fun/ 2>/dev/null | head -1 || echo "nginx fail"
echo "=== BOT ==="
pm2 show vpn-bot 2>/dev/null | grep -E "status|pid|uptime|memory"
