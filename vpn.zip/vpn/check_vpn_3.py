import paramiko
import sys

# Ensure utf-8 output for windows console
sys.stdout.reconfigure(encoding='utf-8')

servers = [
    {"name": "Sweden", "ip": "64.188.81.198", "user": "root", "pass": "rqrecBUtBVNcKKX5"},
    {"name": "Estonia", "ip": "95.85.249.79", "user": "root", "pass": "FNvhSI1r4VVdbj7G"}
]

commands = [
    "echo '--- Xray Service Status ---'",
    "systemctl status xray --no-pager",
    "echo '--- Xray Processes ---'",
    "ps aux | grep -iE 'xray|x-ui|marzban|v2ray|3x-ui'",
    "echo '--- Xray Logs ---'",
    "journalctl -u xray -n 30 --no-pager",
    "echo '--- Checking Marzban or 3x-ui ---'",
    "ls -la /opt/marzban /usr/local/x-ui /etc/x-ui 2>/dev/null",
    "echo '--- Checking other services ---'",
    "systemctl list-units --type=service --state=running | grep -iE 'ui|panel'"
]

for s in servers:
    print(f"\n==================== Checking {s['name']} ({s['ip']}) ====================")
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(s['ip'], username=s['user'], password=s['pass'], timeout=10)
        
        for cmd in commands:
            stdin, stdout, stderr = client.exec_command(cmd)
            out = stdout.read().decode('utf-8', errors='replace').strip()
            if out:
                print(out)
        
        client.close()
    except Exception as e:
        print(f"Failed to connect to {s['name']} ({s['ip']}): {e}")
