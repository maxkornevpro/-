#!/usr/bin/env python3
"""Fix pip and install aiogram."""
import paramiko
import time

HOST = "64.188.81.198"
USER = "root"
PASSWORD = "rqrecBUtBVNcKKX5"

def fix():
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(HOST, username=USER, password=PASSWORD, timeout=30)
    
    print("Upgrading pip...")
    stdin, stdout, stderr = client.exec_command(
        "/root/vpn_bot/venv/bin/python -m pip install --upgrade pip"
    )
    time.sleep(10)
    
    print("Installing aiogram...")
    stdin, stdout, stderr = client.exec_command(
        "/root/vpn_bot/venv/bin/pip install aiogram"
    )
    
    for i in range(30):
        time.sleep(2)
        stdin, stdout, stderr = client.exec_command("ps aux | grep pip | grep -v grep")
        if not stdout.read().decode().strip():
            print(f"Done after {i+1} checks")
            break
    
    print("Check install:")
    stdin, stdout, stderr = client.exec_command(
        "/root/vpn_bot/venv/bin/python -c 'import aiogram; print(\"OK\")'"
    )
    result = stdout.read().decode().strip()
    print(f"Result: [{result}]")
    
    if result == "OK":
        print("Starting bot...")
        client.exec_command(
            "cd /root/vpn_bot && nohup venv/bin/python bot.py > bot.log 2>&1 &"
        )
        time.sleep(3)
        
        stdin, stdout, stderr = client.exec_command(
            "ps aux | grep bot.py | grep -v grep"
        )
        if "bot.py" in stdout.read().decode():
            print("✅ Bot running!")
        else:
            print("❌ Bot failed")
    else:
        print("❌ aiogram not installed")
        stdin, stdout, stderr = client.exec_command(
            "/root/vpn_bot/venv/bin/pip list 2>&1 | grep -i aio"
        )
        print("Packages:", stdout.read().decode())
    
    client.close()

if __name__ == "__main__":
    fix()
