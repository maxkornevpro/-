#!/usr/bin/env python3
"""Install aiogram and start bot."""
import paramiko
import time

HOST = "64.188.81.198"
USER = "root"
PASSWORD = "rqrecBUtBVNcKKX5"

def setup():
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(HOST, username=USER, password=PASSWORD, timeout=30)
    
    print("Installing aiogram...")
    stdin, stdout, stderr = client.exec_command("cd /root/vpn_bot && venv/bin/pip install aiogram paramiko")
    
    for i in range(20):
        time.sleep(2)
        stdin, stdout, stderr = client.exec_command("ps aux | grep pip | grep -v grep")
        if not stdout.read().decode().strip():
            print("Pip done")
            break
    
    time.sleep(3)
    
    print("Testing...")
    stdin, stdout, stderr = client.exec_command("cd /root/vpn_bot && venv/bin/python -c 'import aiogram; print(\"OK\")'")
    print("Result:", stdout.read().decode().strip())
    
    print("Starting bot...")
    client.exec_command("cd /root/vpn_bot && nohup venv/bin/python bot.py > bot.log 2>&1 &")
    time.sleep(3)
    
    stdin, stdout, stderr = client.exec_command("ps aux | grep bot.py | grep -v grep")
    if "bot.py" in stdout.read().decode():
        print("✅ Bot running!")
    else:
        print("❌ Bot failed")
        stdin, stdout, stderr = client.exec_command("cat /root/vpn_bot/bot.log | tail -5")
        print("Log:", stdout.read().decode())
    
    client.close()

if __name__ == "__main__":
    setup()
