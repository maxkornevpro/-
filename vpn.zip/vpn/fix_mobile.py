import paramiko
import json
import sys

sys.stdout.reconfigure(encoding='utf-8')

# Server configs
SERVERS = [
    {"name": "Sweden", "host": "64.188.81.198", "password": "rqrecBUtBVNcKKX5"},
    {"name": "Estonia", "host": "95.85.249.79", "password": "FNvhSI1r4VVdbj7G"}
]

USER = "root"

# Optimized XRay config for mobile with MTU settings
XRAY_CONFIG = {
    "log": {
        "loglevel": "warning"
    },
    "inbounds": [
        {
            "port": 443,
            "protocol": "vless",
            "settings": {
                "clients": [],
                "decryption": "none"
            },
            "streamSettings": {
                "network": "tcp",
                "security": "reality",
                "realitySettings": {
                    "show": False,
                    "dest": "www.google.com:443",
                    "xver": 0,
                    "serverNames": [
                        "www.google.com",
                        "www.youtube.com",
                        "google.com"
                    ],
                    "privateKey": "",  # Will be set by existing key
                    "shortIds": ["", "01", "02", "03"]  # Will use existing
                }
            },
            "sniffing": {
                "enabled": True,
                "destOverride": ["http", "tls", "quic"]
            }
        }
    ],
    "outbounds": [
        {
            "protocol": "freedom",
            "settings": {
                "domainStrategy": "UseIPv4"
            },
            "streamSettings": {
                "sockopt": {
                    "tcpFastOpen": True
                }
            }
        },
        {
            "protocol": "blackhole",
            "settings": {},
            "tag": "blocked"
        }
    ],
    "routing": {
        "domainStrategy": "IPIfNonMatch",
        "rules": [
            {
                "type": "field",
                "ip": ["geoip:private"],
                "outboundTag": "blocked"
            }
        ]
    },
    "policy": {
        "levels": {
            "0": {
                "handshake": 2,
                "connIdle": 120,
                "uplinkOnly": 1,
                "downlinkOnly": 1,
                "statsUserUplink": False,
                "statsUserDownlink": False,
                "bufferSize": 4096
            }
        },
        "system": {
            "statsInboundUplink": False,
            "statsInboundDownlink": False,
            "statsOutboundUplink": False,
            "statsOutboundDownlink": False
        }
    }
}

def fix_server(server):
    print(f"\n🔧 Fixing {server['name']} ({server['host']})...")
    
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(server['host'], username=USER, password=server['password'], timeout=30)
    
    # Find current config
    stdin, stdout, stderr = client.exec_command("cat /usr/local/etc/xray/config.json 2>/dev/null || cat /etc/xray/config.json 2>/dev/null")
    current_config = stdout.read().decode()
    
    if not current_config.strip():
        print("❌ No config found!")
        client.close()
        return
    
    try:
        config = json.loads(current_config)
        
        # Add MTU to streamSettings if exists
        if 'inbounds' in config:
            for inbound in config['inbounds']:
                if 'streamSettings' in inbound:
                    # Set MTU for mobile optimization
                    if 'tcpSettings' not in inbound['streamSettings']:
                        inbound['streamSettings']['tcpSettings'] = {}
                    
                    # Add sockopt with MTU-friendly settings
                    inbound['streamSettings']['sockopt'] = {
                        "tcpFastOpen": True,
                        "tcpNoDelay": True
                    }
                
                # Add sniffing for better routing
                if 'sniffing' not in inbound:
                    inbound['sniffing'] = {
                        "enabled": True,
                        "destOverride": ["http", "tls", "quic"]
                    }
        
        # Add policy for connection limits if not exists
        if 'policy' not in config:
            config['policy'] = {
                "levels": {
                    "0": {
                        "handshake": 2,
                        "connIdle": 120,
                        "uplinkOnly": 1,
                        "downlinkOnly": 1,
                        "bufferSize": 4096
                    }
                }
            }
        
        # Write new config
        new_config = json.dumps(config, indent=2, ensure_ascii=False)
        
        # Save via echo (escape properly)
        stdin, stdout, stderr = client.exec_command(f"cat > /usr/local/etc/xray/config.json << 'EOF'\n{new_config}\nEOF")
        exit_code = stdout.channel.recv_exit_status()
        
        if exit_code == 0:
            print("✅ Config updated with mobile optimizations")
            
            # Restart XRay
            stdin, stdout, stderr = client.exec_command("systemctl restart xray || service xray restart")
            stdout.channel.recv_exit_status()
            
            # Check status
            stdin, stdout, stderr = client.exec_command("sleep 2 && systemctl is-active xray || service xray status | grep -q running && echo 'active'")
            status = stdout.read().decode().strip()
            
            if status == "active":
                print("✅ XRay restarted successfully")
            else:
                print("⚠️  XRay status unknown, checking...")
                stdin, stdout, stderr = client.exec_command("ps aux | grep xray | grep -v grep | wc -l")
                count = int(stdout.read().decode().strip() or 0)
                if count > 0:
                    print("✅ XRay process running")
                else:
                    print("❌ XRay not running!")
        else:
            print(f"❌ Failed to write config: {stderr.read().decode()}")
            
    except json.JSONDecodeError as e:
        print(f"❌ Invalid JSON in config: {e}")
    
    client.close()
    print(f"✅ {server['name']} done")

# Fix both servers
for server in SERVERS:
    fix_server(server)

print("\n" + "="*50)
print("🎉 All servers optimized for mobile!")
print("="*50)
print("\nChanges made:")
print("• Added tcpFastOpen for faster connections")
print("• Added tcpNoDelay to reduce latency")
print("• Enabled sniffing for better routing")
print("• Optimized connection buffer settings")
print("\nThese settings should improve mobile performance.")
