#!/usr/bin/env python3
"""Check VPN public key."""
import paramiko

HOST = "64.188.81.198"
USER = "root"
PASSWORD = "rqrecBUtBVNcKKX5"

def check():
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(HOST, username=USER, password=PASSWORD, timeout=30)
    
    print("Firewall status:")
    stdin, stdout, stderr = client.exec_command("ufw status")
    print(stdout.read().decode()[:200])
    
    print("\nGet private key from config:")
    cmd = """python3 -c "import json; d=json.load(open('/usr/local/etc/xray/config.json')); print(d['inbounds'][0]['streamSettings']['realitySettings']['privateKey'])" """
    stdin, stdout, stderr = client.exec_command(cmd)
    priv_key = stdout.read().decode().strip()
    print(f"Private key: {priv_key[:30]}...")
    
    print("\nGenerate public key:")
    cmd2 = f"""/usr/local/bin/xray x25519 --input='{priv_key}'"""
    stdin, stdout, stderr = client.exec_command(cmd2)
    output = stdout.read().decode()
    print(f"x25519 output:\n{output}")
    
    client.close()

if __name__ == "__main__":
    check()
