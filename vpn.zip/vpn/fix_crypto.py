import paramiko
import sys
import time

sys.stdout.reconfigure(encoding='utf-8')

HOST = "64.188.81.198"
USER = "root"
PASSWORD = "rqrecBUtBVNcKKX5"

print(f"Connecting to {HOST}...")
client = paramiko.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect(HOST, username=USER, password=PASSWORD, timeout=30)

print("Installing aiocryptopay...")
stdin, stdout, stderr = client.exec_command("pip3 install aiocryptopay")
print(stdout.read().decode())
err = stderr.read().decode()
if err:
    print("Stderr:", err)

print("Checking installation...")
stdin, stdout, stderr = client.exec_command("python3 -c 'from aiocryptopay import AioCryptoPay; print(\"OK\")'")
result = stdout.read().decode().strip()
print("Result:", result)

if result == "OK":
    print("Restarting bot...")
    client.exec_command("pkill -f 'python3 bot.py' 2>/dev/null || true")
    time.sleep(2)
    stdin, stdout, stderr = client.exec_command("cd /root/vpn_bot && nohup python3 bot.py > bot.log 2>&1 &")
    stdout.channel.recv_exit_status()
    time.sleep(2)
    
    stdin, stdout, stderr = client.exec_command("ps aux | grep bot.py | grep -v grep")
    processes = stdout.read().decode().strip()
    print("Running processes:", processes if processes else "None")
else:
    print("Installation failed!")

client.close()
print("Done!")
