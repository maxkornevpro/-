import paramiko
import sys

sys.stdout.reconfigure(encoding='utf-8')

HOST = "64.188.81.198"
USER = "root"
PASSWORD = "rqrecBUtBVNcKKX5"

client = paramiko.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect(HOST, username=USER, password=PASSWORD, timeout=30)

stdin, stdout, stderr = client.exec_command("sed -n '360,370p' /root/vpn_bot/bot.py")
print("Lines 360-370:")
print(stdout.read().decode())

stdin, stdout, stderr = client.exec_command("cat /root/vpn_bot/bot.py | wc -l")
print("Total lines:", stdout.read().decode())

client.close()
