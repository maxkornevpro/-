import paramiko
import sys
import time

sys.stdout.reconfigure(encoding='utf-8')

HOST = "64.188.81.198"
USER = "root"
PASSWORD = "rqrecBUtBVNcKKX5"
FILES = [
    (r"C:\Users\терка\Desktop\vpn\bot\config.py", "/root/vpn_bot/config.py"),
    (r"C:\Users\терка\Desktop\vpn\bot\vpn_manager.py", "/root/vpn_bot/vpn_manager.py"),
    (r"C:\Users\терка\Desktop\vpn\bot\subscription_api.py", "/root/vpn_bot/subscription_api.py"),
    (r"C:\Users\терка\Desktop\vpn\bot\panel_3xui.py", "/root/vpn_bot/panel_3xui.py"),
]

print(f"Connecting to {HOST}...")
client = paramiko.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect(HOST, username=USER, password=PASSWORD, timeout=30)

sftp = client.open_sftp()

for local, remote in FILES:
    print(f"Uploading {local.split('\\')[-1]}...")
    try:
        sftp.put(local, remote)
        print(f"  ✅ Done")
    except Exception as e:
        print(f"  ❌ Error: {e}")

sftp.close()

print("\nRestarting bot...")
client.exec_command("pkill -f 'python3 bot.py' 2>/dev/null || true")
time.sleep(2)
client.exec_command("cd /root/vpn_bot && nohup python3 bot.py > bot.log 2>&1 &")

print("Restarting API...")
client.exec_command("pkill -f 'subscription_api.py' 2>/dev/null || true")
time.sleep(1)
client.exec_command("cd /root/vpn_bot && nohup python3 subscription_api.py > api.log 2>&1 &")

time.sleep(2)
stdin, stdout, stderr = client.exec_command("ps aux | grep python3 | grep -v grep | wc -l")
count = stdout.read().decode().strip()
print(f"\nRunning Python processes: {count}")

client.close()
print("\n✅ Upload and restart complete!")
