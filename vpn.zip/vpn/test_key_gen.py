#!/usr/bin/env python3
import sys
sys.path.insert(0, "/opt/aeroprojectvpn")
from vpn_manager import VPNManager
vpn = VPNManager()
try:
    key = vpn.generate_vpn_key(99999, days=1)
    print("SUCCESS")
    print("UUID:", key["uuid"])
    print("LINK:", key["vless_link"][:120])
except Exception as e:
    print("ERROR:", e)
    import traceback
    traceback.print_exc()
