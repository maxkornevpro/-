import paramiko

# Check Sweden
print("=== Sweden (64.188.81.198) ===")
try:
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    c.connect('64.188.81.198', username='root', password='rqrecBUtBVNcKKX5', timeout=30)
    
    s1 = c.exec_command('systemctl is-active x-ui')
    print(f"Status: {s1[1].read().decode().strip()}")
    
    s2 = c.exec_command('ss -tlnp | grep 62789')
    print(f"Port 62789: {s2[1].read().decode().strip()[:100]}")
    
    s3 = c.exec_command('curl -s http://127.0.0.1:62789/login 2>&1 | head -1')
    response = s3[1].read().decode().strip()
    print(f"Local test: {'OK' if response else 'NO RESPONSE'}")
    
    c.close()
    print(f"\n👉 Sweden panel: http://64.188.81.198:62789")
except Exception as e:
    print(f"Error: {e}")

print("\n" + "="*50)

# Check Estonia
print("=== Estonia (95.85.249.79) ===")
try:
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    c.connect('95.85.249.79', username='root', password='FNvhSI1r4VVdbj7G', timeout=30)
    
    s1 = c.exec_command('systemctl is-active x-ui')
    print(f"Status: {s1[1].read().decode().strip()}")
    
    s2 = c.exec_command('ls /usr/local/x-ui/x-ui.db 2>/dev/null && echo DB_EXISTS || echo NO_DB')
    print(f"Install: {s2[1].read().decode().strip()}")
    
    c.close()
except Exception as e:
    print(f"Error: {e}")

print("\n✅ Бот обновлён с правильным портом Швеции (62789)")
