import paramiko
import sys
import time

sys.stdout.reconfigure(encoding='utf-8')

SERVERS = [
    {"name": "Germany", "host": "2.26.54.63", "password": "qwerty1109max"},
]

USER = "root"

def check_and_install_3xui(server):
    print(f"\n{'='*50}")
    print(f"🔧 Checking 3x-ui on {server['name']} ({server['host']})...")
    print('='*50)
    
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    try:
        client.connect(server['host'], username=USER, password=server['password'], timeout=30)
        
        # Check if 3x-ui installed
        stdin, stdout, stderr = client.exec_command("which x-ui || ls /usr/local/x-ui/ 2>/dev/null | head -1")
        result = stdout.read().decode().strip()
        
        if result:
            print(f"✅ 3x-ui already installed: {result}")
            
            # Check if running
            stdin, stdout, stderr = client.exec_command("systemctl is-active x-ui 2>/dev/null || echo 'not running'")
            status = stdout.read().decode().strip()
            print(f"📊 Status: {status}")
            
            if status != "active":
                print("🔄 Starting 3x-ui...")
                client.exec_command("systemctl start x-ui || x-ui start")
                time.sleep(2)
        else:
            print("⬇️  3x-ui not found, installing...")
            
            # Install 3x-ui
            install_cmd = """bash <(curl -Ls https://raw.githubusercontent.com/mhsanaei/3x-ui/master/install.sh) << 'INSTALLEOF'
y
y
y
INSTALLEOF"""
            
            stdin, stdout, stderr = client.exec_command(install_cmd, timeout=300)
            
            # Wait for install (stream output)
            output = ""
            while not stdout.channel.exit_status_ready():
                if stdout.channel.recv_ready():
                    chunk = stdout.channel.recv(1024).decode()
                    output += chunk
                    if len(output) > 2000:
                        output = output[-1000:]
            
            exit_code = stdout.channel.recv_exit_status()
            
            if exit_code == 0:
                print("✅ 3x-ui installed successfully!")
            else:
                err = stderr.read().decode()[-500:]
                print(f"⚠️  Install may have issues: {err}")
        
        # Get 3x-ui port
        stdin, stdout, stderr = client.exec_command('cat /usr/local/x-ui/bin/config.json 2>/dev/null | grep -o \'"port":[0-9]*\' | cut -d: -f2 || echo \'54321\'')
        port = stdout.read().decode().strip() or "54321"
        print(f"🌐 3x-ui panel port: {port}")
        
        # Check firewall
        stdin, stdout, stderr = client.exec_command(f"ufw status | grep {port} || iptables -L | grep {port} || echo 'port not explicitly opened'")
        fw = stdout.read().decode().strip()
        if 'not' in fw:
            print(f"🔓 Opening port {port}...")
            client.exec_command(f"ufw allow {port}/tcp 2>/dev/null || iptables -I INPUT -p tcp --dport {port} -j ACCEPT 2>/dev/null || true")
        
        # Get public key from XRay config for panel
        stdin, stdout, stderr = client.exec_command('cat /usr/local/x-ui/bin/config.json 2>/dev/null | grep -o \'"publicKey":"[^"]*"\' | head -1 || cat /usr/local/etc/xray/config.json 2>/dev/null | grep -o \'publicKey[^,]*\'')
        pubkey = stdout.read().decode().strip()
        if pubkey:
            print(f"🔑 Found public key: {pubkey[:50]}...")
        
        client.close()
        print(f"✅ {server['name']} ready!")
        return True
        
    except Exception as e:
        print(f"❌ Error with {server['name']}: {e}")
        try:
            client.close()
        except:
            pass
        return False

print("="*50)
print("🔧 SETTING UP 3X-UI ON ALL SERVERS")
print("="*50)

for server in SERVERS:
    check_and_install_3xui(server)
    time.sleep(2)

print("\n" + "="*50)
print("✅ 3X-UI SETUP COMPLETE")
print("="*50)
print("\n📋 Access panels:")
print("   Sweden:  http://64.188.81.198:54321")
print("   Estonia: http://95.85.249.79:54321")
print("\n🔑 Default login: admin / admin")
print("   Change password after first login!")
