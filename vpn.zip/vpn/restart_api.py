#!/usr/bin/env python3
"""Restart API server on Sweden VPS."""

import paramiko

HOST = "64.188.81.198"
USER = "root"
PASSWORD = "rqrecBUtBVNcKKX5"

def ssh_connect():
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(HOST, username=USER, password=PASSWORD, timeout=30)
    return client

def restart_api():
    print("🔄 Restarting API server...")
    client = ssh_connect()
    
    # Kill existing API
    print("🛑 Stopping old API...")
    client.exec_command("pkill -f subscription_api.py")
    
    import time
    time.sleep(2)
    
    # Start new API
    print("🚀 Starting API...")
    client.exec_command("cd /root/vpn_bot && nohup python3 subscription_api.py > api.log 2>&1 &")
    time.sleep(3)
    
    # Check if running
    stdin, stdout, stderr = client.exec_command("ps aux | grep subscription_api | grep -v grep")
    processes = stdout.read().decode()
    
    if "subscription_api.py" in processes:
        print("✅ API is running!")
    else:
        print("❌ API failed to start")
        stdin, stdout, stderr = client.exec_command("cat /root/vpn_bot/api.log | tail -20")
        print("📋 Error log:", stdout.read().decode())
    
    print("\n🔗 Test URL: http://64.188.81.198:8080/")
    client.close()

if __name__ == "__main__":
    restart_api()
