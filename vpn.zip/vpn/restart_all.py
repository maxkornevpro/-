#!/usr/bin/env python3
"""Use system python and restart services."""
import paramiko
import time

HOST = "64.188.81.198"
USER = "root"
PASSWORD = "rqrecBUtBVNcKKX5"

def restart():
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(HOST, username=USER, password=PASSWORD, timeout=30)
    
    print("Installing packages...")
    client.exec_command("pip3 install --break-system-packages aiogram paramiko flask")
    
    for i in range(15):
        time.sleep(2)
        stdin, stdout, stderr = client.exec_command("ps aux | grep pip3 | grep -v grep")
        if not stdout.read().decode().strip():
            break
    
    print("Testing...")
    stdin, stdout, stderr = client.exec_command("python3 -c 'import aiogram; print(\"OK\")'")
    print("aiogram:", stdout.read().decode().strip())
    
    stdin, stdout, stderr = client.exec_command("python3 -c 'from flask import Flask; print(\"OK\")'")
    print("flask:", stdout.read().decode().strip())
    
    print("Killing old processes...")
    client.exec_command("pkill -9 -f bot.py; pkill -9 -f subscription_api; pkill -9 node; sleep 3")
    time.sleep(4)
    
    print("Starting services...")
    client.exec_command("cd /root/vpn_bot && nohup python3 bot.py > bot.log 2>&1 &")
    time.sleep(2)
    client.exec_command("cd /root/vpn_bot && nohup python3 subscription_api.py > api.log 2>&1 &")
    time.sleep(3)
    
    stdin, stdout, stderr = client.exec_command("ps aux | grep python3 | grep -v grep")
    result = stdout.read().decode()
    if "bot.py" in result and "subscription_api" in result:
        print("✅ Both running!")
    else:
        print("Status:", result[:400])
    
    client.close()

if __name__ == "__main__":
    restart()
