import paramiko
import sys
import json

sys.stdout.reconfigure(encoding='utf-8')

servers = [
    {"name": "Sweden", "ip": "64.188.81.198", "user": "root", "pass": "rqrecBUtBVNcKKX5"},
    {"name": "Estonia", "ip": "95.85.249.79", "user": "root", "pass": "FNvhSI1r4VVdbj7G"}
]

for s in servers:
    print(f"\n==================== Fixing {s['name']} ({s['ip']}) ====================")
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(s['ip'], username=s['user'], password=s['pass'], timeout=10)
        
        # Get current config
        stdin, stdout, stderr = client.exec_command("cat /usr/local/etc/xray/config.json")
        config_str = stdout.read().decode('utf-8').strip()
        config = json.loads(config_str)
        
        changed = False
        target_uuid = "453e965b-c549-4cd4-9abd-cdea811c0ffe"
        
        # Check if UUID is in the first inbound
        clients = config.get("inbounds", [])[0].get("settings", {}).get("clients", [])
        uuids = [c.get("id") for c in clients]
        
        if target_uuid not in uuids:
            print(f"UUID {target_uuid} not found. Adding it...")
            clients.append({
                "id": target_uuid,
                "flow": "xtls-rprx-vision"
            })
            config["inbounds"][0]["settings"]["clients"] = clients
            changed = True
        else:
            print(f"UUID {target_uuid} already exists.")
            
        # If changed, write it back
        if changed:
            new_config_str = json.dumps(config, indent=2)
            # escape single quotes for echo
            new_config_str = new_config_str.replace("'", "'\"'\"'")
            client.exec_command(f"echo '{new_config_str}' > /usr/local/etc/xray/config.json")
            print("Config updated.")
            
        # Restart xray
        print("Restarting xray service...")
        client.exec_command("systemctl restart xray")
        
        client.close()
    except Exception as e:
        print(f"Failed to connect or fix {s['name']} ({s['ip']}): {e}")
