#!/usr/bin/env python3
"""
Установка MTProto прокси для Telegram на Germany сервере (2.26.54.63).
Использует Paramiko для SSH подключения.
MTProto прокси позволяет Telegram работать без VPN.
"""

import secrets
import time

import paramiko

# Germany server credentials from config
VPS_HOST = "2.26.54.63"
VPS_USER = "root"
VPS_PASSWORD = "qwerty1109max"
VPS_PORT = 22

# MTProto proxy settings
MTPROTO_PORT = 8443  # Port for MTProto (443 is occupied by Xray VPN)
MTPROTO_TAG = "@AeroProjectVpn"  # Tag channel for proxy


def ssh_connect(max_retries=3):
    """Подключение к серверу через Paramiko SSH с retry."""
    for attempt in range(1, max_retries + 1):
        try:
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect(
                VPS_HOST,
                port=VPS_PORT,
                username=VPS_USER,
                password=VPS_PASSWORD,
                timeout=30,
                banner_timeout=30,
            )
            return client
        except Exception as e:
            print(f"  Попытка {attempt}/{max_retries} не удалась: {e}")
            if attempt < max_retries:
                time.sleep(5)
    raise RuntimeError(f"Не удалось подключиться к {VPS_HOST} после {max_retries} попыток")


def run_command(client, command, timeout=120):
    """Выполнить команду на сервере и вернуть вывод."""
    print(f"  > {command[:100]}...")
    stdin, stdout, stderr = client.exec_command(command, timeout=timeout)
    exit_code = stdout.channel.recv_exit_status()
    out = stdout.read().decode().strip()
    err = stderr.read().decode().strip()
    if exit_code != 0 and err:
        print(f"    stderr: {err[:200]}")
    return out, err, exit_code


def generate_secret():
    """Генерация секрета для MTProto прокся (32 hex символа)."""
    return secrets.token_hex(16)


def check_existing_mtg(client):
    """Проверить, установлен ли уже mtg."""
    out, _, _ = run_command(client, "which mtg 2>/dev/null || echo 'not_found'")
    return out != "not_found"


def install_mtg(client):
    """Установка mtg (MTProto proxy для Telegram) на сервер."""
    print("\n[1/5] Установка зависимостей и mtg...")

    # Detect architecture
    out, _, _ = run_command(client, "uname -m")
    arch = out.strip()
    if arch == "x86_64":
        mtg_arch = "amd64"
    elif arch == "aarch64":
        mtg_arch = "arm64"
    else:
        mtg_arch = "amd64"

    print(f"  Архитектура: {arch} -> mtg: {mtg_arch}")

    # Download and install mtg
    # Get latest version from GitHub API
    version_cmd = "curl -sI https://github.com/9seconds/mtg/releases/latest 2>&1 | grep -i '^location:' | sed 's|.*/tag/||' | tr -d '\\r\\n'"
    out, _, _ = run_command(client, version_cmd)
    mtg_version = out.strip() if out.strip().startswith("v") else "v2.2.8"
    print(f"  Версия mtg: {mtg_version}")
    ver_num = mtg_version.lstrip("v")

    commands = [
        "apt-get update -qq",
        "apt-get install -y -qq curl wget",
        # Download specific mtg release with correct filename format
        f"curl -sL https://github.com/9seconds/mtg/releases/download/{mtg_version}/mtg-{ver_num}-linux-{mtg_arch}.tar.gz -o /tmp/mtg.tar.gz",
        "mkdir -p /opt/mtg",
        "tar -xzf /tmp/mtg.tar.gz -C /opt/mtg",
        # Find the mtg binary (could be in subdirectory or at root of archive)
        "cp /opt/mtg/mtg /usr/local/bin/mtg 2>/dev/null || find /opt/mtg -name 'mtg' -type f -exec cp {} /usr/local/bin/mtg \\;",
        "chmod +x /usr/local/bin/mtg",
    ]

    for cmd in commands:
        out, err, code = run_command(client, cmd, timeout=180)
        if code != 0 and "curl" not in cmd and "apt" not in cmd:
            print(f"  WARNING: команда завершилась с кодом {code}")

    # Verify installation
    out, _, _ = run_command(client, "mtg version 2>/dev/null || mtg --version 2>/dev/null || echo 'installed'")
    print(f"  mtg установлен: {out[:50]}")


def generate_mtg_secret(client):
    """Генерация секрета для mtg с использованием dd секрета."""
    print("\n[2/5] Генерация секрета...")

    # Generate secret with domain fronting (hostname for cloaking)
    out, _, _ = run_command(client, "mtg generate-secret de.aeroproject.fun")
    secret = out.strip()

    if not secret or len(secret) < 10:
        # Fallback: generate without domain fronting
        out, _, _ = run_command(client, "mtg generate-secret 2.26.54.63")
        secret = out.strip()

    if not secret or len(secret) < 10:
        # Last fallback: generate raw hex secret
        raw_secret = generate_secret()
        secret = f"ee{raw_secret}"
        print(f"  Секрет сгенерирован (raw fallback): {secret[:10]}...")
    else:
        print(f"  Секрет сгенерирован: {secret[:10]}...")

    return secret


def setup_systemd_service(client, secret):
    """Создание systemd сервиса для mtg."""
    print("\n[3/5] Настройка systemd сервиса...")

    service_content = f"""[Unit]
Description=MTProto Proxy for Telegram (mtg)
After=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/mtg simple-run 0.0.0.0:{MTPROTO_PORT} {secret}
Restart=always
RestartSec=5
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
"""

    # Write service file
    cmd = f"cat > /etc/systemd/system/mtg.service << 'EOFSERVICE'\n{service_content}EOFSERVICE"
    run_command(client, cmd)

    # Enable and start service
    commands = [
        "systemctl daemon-reload",
        "systemctl enable mtg",
        "systemctl stop mtg 2>/dev/null || true",
        "systemctl start mtg",
    ]

    for cmd in commands:
        run_command(client, cmd)

    # Wait and check status
    time.sleep(3)
    out, _, _ = run_command(client, "systemctl is-active mtg")
    print(f"  Статус сервиса: {out}")


def configure_firewall(client):
    """Настройка файрвола для MTProto прокси."""
    print("\n[4/5] Настройка файрвола...")

    commands = [
        f"ufw allow {MTPROTO_PORT}/tcp 2>/dev/null || true",
        f"ufw allow {MTPROTO_PORT}/udp 2>/dev/null || true",
        f"iptables -C INPUT -p tcp --dport {MTPROTO_PORT} -j ACCEPT 2>/dev/null || iptables -A INPUT -p tcp --dport {MTPROTO_PORT} -j ACCEPT",
        f"iptables -C INPUT -p udp --dport {MTPROTO_PORT} -j ACCEPT 2>/dev/null || iptables -A INPUT -p udp --dport {MTPROTO_PORT} -j ACCEPT",
        # Save iptables rules
        "which netfilter-persistent >/dev/null 2>&1 && netfilter-persistent save || true",
        "which iptables-save >/dev/null 2>&1 && iptables-save > /etc/iptables/rules.v4 2>/dev/null || true",
    ]

    for cmd in commands:
        run_command(client, cmd)

    print(f"  Порт {MTPROTO_PORT} открыт в файрволе")


def verify_proxy(client, secret):
    """Проверка что прокси работает."""
    print("\n[5/5] Проверка прокси...")

    # Check service status
    out, _, _ = run_command(client, "systemctl is-active mtg")
    if out == "active":
        print("  ✅ Сервис mtg запущен")
    else:
        print(f"  ❌ Сервис mtg не запущен (статус: {out})")
        # Try to get logs
        log_out, _, _ = run_command(client, "journalctl -u mtg -n 20 --no-pager")
        print(f"  Логи:\n{log_out[:500]}")

    # Check port is listening
    out, _, _ = run_command(client, f"ss -tlnp | grep {MTPROTO_PORT} || netstat -tlnp | grep {MTPROTO_PORT}")
    if out:
        print(f"  ✅ Порт {MTPROTO_PORT} слушает")
    else:
        print(f"  ⚠️ Порт {MTPROTO_PORT} не найден в слушающих")

    return out == "active"


def main():
    print("=" * 60)
    print("  Установка MTProto прокси для Telegram")
    print(f"  Сервер: {VPS_HOST}")
    print(f"  Порт прокси: {MTPROTO_PORT}")
    print("=" * 60)

    # Connect to server
    print("\nПодключение к серверу...")
    client = ssh_connect()
    print("  ✅ Подключено")

    try:
        # Check if already installed
        if check_existing_mtg(client):
            print("  mtg уже установлен, обновляем...")
        else:
            install_mtg(client)

        # Generate secret
        secret = generate_mtg_secret(client)

        # Setup systemd service
        setup_systemd_service(client, secret)

        # Configure firewall
        configure_firewall(client)

        # Verify
        is_active = verify_proxy(client, secret)

        # Generate proxy link
        proxy_link = f"tg://proxy?server={VPS_HOST}&port={MTPROTO_PORT}&secret={secret}"

        print("\n" + "=" * 60)
        print("  РЕЗУЛЬТАТ")
        print("=" * 60)

        if is_active:
            print(f"\n  ✅ MTProto прокси УСПЕШНО установлен!")
        else:
            print(f"\n  ⚠️ MTProto прокси установлен, но есть проблемы")

        print(f"\n  Ссылка для подключения к прокси:")
        print(f"  {proxy_link}")
        print(f"\n  Секрет: {secret}")
        print(f"  Сервер: {VPS_HOST}:{MTPROTO_PORT}")
        print(f"\n  Как использовать:")
        print(f"  1. Откройте ссылку в Telegram")
        print(f"  2. Или: Настройки -> Данные и память -> Прокси -> Добавить прокси")
        print(f"  3. Вставьте сервер: {VPS_HOST}, порт: {MTPROTO_PORT}, секрет: {secret}")

        # Save proxy info to file
        with open("mtproto_proxy_info.txt", "w") as f:
            f.write(f"MTProto Proxy Info\n")
            f.write(f"==================\n")
            f.write(f"Server: {VPS_HOST}\n")
            f.write(f"Port: {MTPROTO_PORT}\n")
            f.write(f"Secret: {secret}\n")
            f.write(f"Link: {proxy_link}\n")
            f.write(f"Tag: {MTPROTO_TAG}\n")

        print(f"\n  Информация сохранена в mtproto_proxy_info.txt")

    finally:
        client.close()
        print("\n  SSH подключение закрыто")


if __name__ == "__main__":
    main()
