import paramiko
import sys
import time

sys.stdout.reconfigure(encoding='utf-8')

HOST = "64.188.81.198"
USER = "root"
PASSWORD = "rqrecBUtBVNcKKX5"

print(f"Connecting to {HOST}...")
client = paramiko.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect(HOST, username=USER, password=PASSWORD, timeout=30)

print("Installing aiocryptopay on server...")
client.exec_command("pip3 install aiocryptopay")

print("Uploading updated files...")
sftp = client.open_sftp()
sftp.put(r"c:\Users\терка\Desktop\vpn\bot\bot.py", "/root/vpn_bot/bot.py")
sftp.put(r"c:\Users\терка\Desktop\vpn\bot\database.py", "/root/vpn_bot/database.py")
sftp.put(r"c:\Users\терка\Desktop\vpn\bot\config.py", "/root/vpn_bot/config.py")
sftp.close()

print("Restarting bot process...")
client.exec_command("pkill -f 'python3 bot.py'")
time.sleep(2)
client.exec_command("cd /root/vpn_bot && nohup python3 bot.py > bot.log 2>&1 &")

print("Done! CryptoBot payment integration deployed.")
client.close()
