#!/usr/bin/env python3
"""
Миграция бота и API с шведского VPS (64.188.81.198) на новый (2.26.54.63)
"""

import paramiko
import os
from pathlib import Path

# Исходный сервер (Швеция)
SOURCE = {
    "host": "64.188.81.198",
    "user": "root",
    "password": "rqrecBUtBVNcKKX5",
}

# Новый сервер
TARGET = {
    "host": "2.26.54.63",
    "user": "root",
    "password": "qwerty1109max",
}

LOCAL_BOT_DIR = Path("/home/terka/Рабочий стол/vpn/bot")
REMOTE_APP_DIR = "/opt/aeroprojectvpn"

def ssh_connect(server):
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(server["host"], username=server["user"], password=server["password"], timeout=20)
    return client

def run(client, command, timeout=120):
    stdin, stdout, stderr = client.exec_command(command, timeout=timeout)
    exit_code = stdout.channel.recv_exit_status()
    out = stdout.read().decode(errors="ignore")
    err = stderr.read().decode(errors="ignore")
    return exit_code, out, err

def main():
    print("=== МИГРАЦИЯ БОТА НА НОВЫЙ VPS ===")
    print(f"Источник: {SOURCE['host']}")
    print(f"Назначение: {TARGET['host']}")
    
    # 1. Подключаемся к новому серверу и устанавливаем зависимости
    print("\n[1/6] Подключение к новому серверу...")
    target_client = ssh_connect(TARGET)
    print("✓ Подключено")
    
    # 2. Устанавливаем необходимые пакеты
    print("\n[2/6] Установка зависимостей...")
    commands = [
        "apt-get update -qq",
        "apt-get install -y -qq python3 python3-pip python3-venv pm2",
        "pm2 startup systemd -u root --hp /root",
    ]
    for cmd in commands:
        print(f"  -> {cmd[:50]}...")
        run(target_client, cmd, timeout=180)
    print("✓ Зависимости установлены")
    
    # 3. Создаем директорию приложения
    print("\n[3/6] Создание директории приложения...")
    run(target_client, f"mkdir -p {REMOTE_APP_DIR}")
    
    # 4. Копируем файлы бота
    print("\n[4/6] Копирование файлов бота...")
    sftp = target_client.open_sftp()
    
    bot_files = [
        "bot.py", "config.py", "database.py", "keyboards.py",
        "panel_3xui.py", "requirements.txt", "subscription_api.py",
        "token_crypto.py", "vpn_manager.py", "vpn_bot.db"
    ]
    
    for fname in bot_files:
        local_path = LOCAL_BOT_DIR / fname
        remote_path = f"{REMOTE_APP_DIR}/{fname}"
        if local_path.exists():
            sftp.put(str(local_path), remote_path)
            print(f"  -> {fname}")
    
    sftp.close()
    print("✓ Файлы скопированы")
    
    # 5. Устанавливаем Python зависимости
    print("\n[5/6] Установка Python пакетов...")
    run(target_client, f"cd {REMOTE_APP_DIR} && pip3 install -q -r requirements.txt", timeout=120)
    print("✓ Python пакеты установлены")
    
    # 6. Запускаем сервисы
    print("\n[6/6] Запуск сервисов...")
    
    # Останавливаем старые процессы если есть
    run(target_client, "pm2 delete vpn-bot 2>/dev/null; pm2 delete subscription-api 2>/dev/null; true")
    
    # Запускаем бота
    run(target_client, f"cd {REMOTE_APP_DIR} && pm2 start bot.py --name vpn-bot --interpreter python3")
    # Запускаем API
    run(target_client, f"cd {REMOTE_APP_DIR} && pm2 start subscription_api.py --name subscription-api --interpreter python3")
    
    # Сохраняем конфигурацию pm2
    run(target_client, "pm2 save")
    
    print("✓ Сервисы запущены")
    
    # Проверяем статус
    print("\n=== СТАТУС НОВОГО СЕРВЕРА ===")
    _, out, _ = run(target_client, "pm2 status")
    print(out)
    
    target_client.close()
    print("\n✅ МИГРАЦИЯ ЗАВЕРШЕНА!")
    print(f"Бот и API перенесены на {TARGET['host']}")

if __name__ == "__main__":
    main()
