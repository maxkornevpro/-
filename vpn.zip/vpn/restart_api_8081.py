#!/usr/bin/env python3
"""Restart API on port 8081."""

import paramiko
import time

HOST = "64.188.81.198"
USER = "root"
PASSWORD = "rqrecBUtBVNcKKX5"

def restart_api():
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(HOST, username=USER, password=PASSWORD, timeout=30)
    
    print("Killing processes...")
    client.exec_command("pkill -9 node; pkill -9 python; sleep 3")
    time.sleep(4)
    
    # Read API file and change port
    print("Changing port to 8081...")
    stdin, stdout, stderr = client.exec_command("cat /root/vpn_bot/subscription_api.py")
    content = stdout.read().decode()
    
    # Replace port
    new_content = content.replace("port=8080", "port=8081")
    
    # Write back using sftp
    sftp = client.open_sftp()
    with sftp.file("/root/vpn_bot/subscription_api.py", "w") as f:
        f.write(new_content)
    sftp.close()
    
    print("Starting API on port 8081...")
    client.exec_command("cd /root/vpn_bot && nohup venv/bin/python subscription_api.py > api.log 2>&1 &")
    time.sleep(3)
    
    stdin, stdout, stderr = client.exec_command("ps aux | grep subscription_api | grep -v grep")
    if "subscription_api" in stdout.read().decode():
        print("✅ API running on port 8081!")
        print("🔗 URL: http://64.188.81.198:8081/sub/TOKEN")
    else:
        print("❌ API failed")
        stdin, stdout, stderr = client.exec_command("cat /root/vpn_bot/api.log | tail -5")
        print("Log:", stdout.read().decode())
    
    # Start bot
    print("Starting bot...")
    client.exec_command("cd /root/vpn_bot && nohup venv/bin/python bot.py > bot.log 2>&1 &")
    time.sleep(2)
    
    client.close()

if __name__ == "__main__":
    restart_api()
