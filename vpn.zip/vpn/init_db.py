#!/usr/bin/env python3
import sys
sys.path.insert(0, '/opt/aeroprojectvpn')
from database import Database
db = Database()
print("DB initialized")
