#!/usr/bin/env python3
"""Fix prices in bot.py on server"""

# Read bot.py
with open('/opt/aeroprojectvpn/bot.py', 'r') as f:
    content = f.read()

# Replace old prices with new ones
replacements = [
    ('1 месяц — 35₽', '1 месяц — 100₽'),
    ('6 месяцев — 50₽', '6 месяцев — 225₽'),
    ('Навсегда — 100₽', '1 год — 400₽'),
    ('forever', '1_year'),  # in case there's plan name
]

for old, new in replacements:
    content = content.replace(old, new)

# Write back
with open('/opt/aeroprojectvpn/bot.py', 'w') as f:
    f.write(content)

print('Prices updated in bot.py')
