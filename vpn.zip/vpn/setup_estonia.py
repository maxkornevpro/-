#!/usr/bin/env python3
"""Setup VPN on Estonia VPS."""

import paramiko
import time

# Estonia VPS
HOST = "95.85.249.79"
USER = "root"
PASSWORD = "FNvhSI1r4VVdbj7G"
PORT = 8443

def ssh_connect():
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(HOST, username=USER, password=PASSWORD, timeout=30)
    return client

def install_xray(client):
    """Install Xray-core on Estonia."""
    print("Installing Xray-core on Estonia VPS...")
    cmd = "bash <(curl -L https://github.com/XTLS/Xray-install/raw/main/install-release.sh) install"
    stdin, stdout, stderr = client.exec_command(cmd)
    exit_status = stdout.channel.recv_exit_status()
    print("Xray installed!")
    return True

def setup_reality_keys(client):
    """Generate Reality keys."""
    print("Generating Reality keys...")
    stdin, stdout, stderr = client.exec_command("xray x25519")
    output = stdout.read().decode()
    
    private_key = None
    public_key = None
    
    for line in output.split('\n'):
        if 'Private' in line:
            private_key = line.split(':')[1].strip()
        if 'Public' in line:
            public_key = line.split(':')[1].strip()
    
    print(f"Estonia Public Key: {public_key}")
    return private_key, public_key

def configure_xray(client, private_key):
    """Configure Xray server."""
    import json
    
    short_id = "8f7c67"
    
    config = {
        "log": {"loglevel": "warning"},
        "inbounds": [
            {
                "listen": "0.0.0.0",
                "port": PORT,
                "protocol": "vless",
                "settings": {
                    "clients": [],
                    "decryption": "none"
                },
                "streamSettings": {
                    "network": "tcp",
                    "security": "reality",
                    "realitySettings": {
                        "dest": "www.google.com:443",
                        "serverNames": ["www.google.com", "google.com"],
                        "privateKey": private_key,
                        "shortIds": [short_id]
                    }
                },
                "sniffing": {
                    "enabled": True,
                    "destOverride": ["http", "tls"]
                }
            }
        ],
        "outbounds": [
            {"protocol": "freedom", "tag": "direct"}
        ]
    }
    
    config_json = json.dumps(config, indent=2)
    cmd = f"cat > /usr/local/etc/xray/config.json << 'EOF'\n{config_json}\nEOF"
    client.exec_command(cmd)
    
    # Restart Xray
    client.exec_command("systemctl restart xray")
    client.exec_command("systemctl enable xray")
    print("Xray configured and started!")

def main():
    print(f"Connecting to Estonia VPS ({HOST})...")
    client = ssh_connect()
    print("Connected!")
    
    # Install Xray
    install_xray(client)
    
    # Generate keys
    private_key, public_key = setup_reality_keys(client)
    print(f"\n=== ESTONIA VPS KEYS ===")
    print(f"Private Key: {private_key}")
    print(f"Public Key: {public_key}")
    print(f"========================\n")
    
    # Configure
    configure_xray(client, private_key)
    
    # Check status
    stdin, stdout, stderr = client.exec_command("systemctl status xray --no-pager | head -10")
    print("\n--- Xray Status ---")
    print(stdout.read().decode())
    
    # Check port
    stdin, stdout, stderr = client.exec_command(f"ss -tlnp | grep {PORT}")
    listening = stdout.read().decode()
    print(f"\n--- Port {PORT} ---")
    print(listening if listening else "Not listening!")
    
    client.close()
    print("\n✅ Estonia VPN server setup complete!")
    print(f"Public Key: {public_key}")
    print("Add this key to config.py VPS2_PUBLIC_KEY")

if __name__ == "__main__":
    main()
