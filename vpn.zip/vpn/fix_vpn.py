#!/usr/bin/env python3
"""Fix Xray configuration."""

import paramiko
import json

HOST = "64.188.81.198"
USER = "root"
PASSWORD = "rqrecBUtBVNcKKX5"
PORT = 443

def ssh_connect():
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(HOST, username=USER, password=PASSWORD, timeout=30)
    return client

def main():
    client = ssh_connect()
    
    # Read current config
    stdin, stdout, stderr = client.exec_command("cat /usr/local/etc/xray/config.json")
    current_config = stdout.read().decode()
    print("Current config:")
    print(current_config)
    
    # Check logs
    print("\n--- Xray logs ---")
    stdin, stdout, stderr = client.exec_command("cat /var/log/xray/error.log | tail -20")
    logs = stdout.read().decode()
    print(logs)
    
    # Get existing UUID and keys from old config if possible
    try:
        old_config = json.loads(current_config)
        user_uuid = old_config['inbounds'][0]['settings']['clients'][0]['id']
        private_key = old_config['inbounds'][0]['streamSettings']['realitySettings']['privateKey']
        public_key = "VGOz4MRejC-P3_CtfRasF1Tpq52vh1LLKxozmRK_wAA"  # From previous output
    except:
        import uuid as uuid_mod
        user_uuid = str(uuid_mod.uuid4())
        # Generate new keys
        stdin, stdout, stderr = client.exec_command("xray x25519")
        output = stdout.read().decode()
        private_key = None
        public_key = None
        for line in output.split('\n'):
            if 'Private' in line:
                private_key = line.split(':')[1].strip()
            if 'Public' in line:
                public_key = line.split(':')[1].strip()
    
    short_id = "8f7c67"
    
    # Create proper config - simpler version without problematic fields
    config = {
        "log": {"loglevel": "warning"},
        "inbounds": [
            {
                "port": PORT,
                "protocol": "vless",
                "settings": {
                    "clients": [
                        {
                            "id": user_uuid,
                            "flow": "xtls-rprx-vision"
                        }
                    ],
                    "decryption": "none"
                },
                "streamSettings": {
                    "network": "tcp",
                    "security": "reality",
                    "realitySettings": {
                        "dest": "www.google.com:443",
                        "serverNames": ["www.google.com"],
                        "privateKey": private_key,
                        "shortIds": [short_id]
                    }
                }
            }
        ],
        "outbounds": [
            {"protocol": "freedom"}
        ]
    }
    
    # Write new config
    config_json = json.dumps(config, indent=2)
    cmd = f"cat > /usr/local/etc/xray/config.json << 'EOF'\n{config_json}\nEOF"
    stdin, stdout, stderr = client.exec_command(cmd)
    
    # Validate config
    print("\n--- Validating config ---")
    stdin, stdout, stderr = client.exec_command("xray run -test -config /usr/local/etc/xray/config.json")
    test_output = stdout.read().decode()
    test_err = stderr.read().decode()
    print(test_output)
    if test_err:
        print("Validation errors:", test_err)
    
    # Restart Xray
    print("\n--- Restarting Xray ---")
    client.exec_command("systemctl stop xray")
    time.sleep(1)
    client.exec_command("systemctl start xray")
    time.sleep(2)
    
    # Check status
    stdin, stdout, stderr = client.exec_command("systemctl status xray --no-pager")
    status = stdout.read().decode()
    print("\n--- Service Status ---")
    print(status[:800])
    
    # Check if port is listening
    stdin, stdout, stderr = client.exec_command("ss -tlnp | grep 443")
    listening = stdout.read().decode()
    print("\n--- Port 443 ---")
    print(listening if listening else "Not listening on 443")
    
    # Generate VLESS link
    vless_link = f"vless://{user_uuid}@{HOST}:{PORT}?flow=xtls-rprx-vision&encryption=none&security=reality&sni=www.google.com&fp=chrome&pbk={public_key}&sid={short_id}&type=tcp&headerType=none#VPN-Sweden"
    
    print("\n" + "="*60)
    print("FINAL VLESS LINK:")
    print("="*60)
    print(vless_link)
    print("="*60)
    
    client.close()

if __name__ == "__main__":
    import time
    main()
