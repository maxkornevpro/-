import paramiko
import sys
import json

sys.stdout.reconfigure(encoding='utf-8')

servers = [
    {"name": "Sweden", "ip": "64.188.81.198", "user": "root", "pass": "rqrecBUtBVNcKKX5"},
    {"name": "Estonia", "ip": "95.85.249.79", "user": "root", "pass": "FNvhSI1r4VVdbj7G"}
]

commands = [
    "cat /usr/local/etc/xray/config.json"
]

for s in servers:
    print(f"\n==================== Config for {s['name']} ({s['ip']}) ====================")
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(s['ip'], username=s['user'], password=s['pass'], timeout=10)
        
        for cmd in commands:
            stdin, stdout, stderr = client.exec_command(cmd)
            out = stdout.read().decode('utf-8', errors='replace').strip()
            
            # Try to pretty print json if possible
            try:
                parsed = json.loads(out)
                print(json.dumps(parsed, indent=2, ensure_ascii=False))
            except:
                print(out)
        
        client.close()
    except Exception as e:
        print(f"Failed to connect to {s['name']} ({s['ip']}): {e}")
