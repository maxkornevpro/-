import paramiko
import os
import sys

# Script to deploy the updated bot to the Germany VPS
HOST = "2.26.54.63"
USER = "root"
PASS = "qwerty1109max"

def deploy():
    print(f"Connecting to VPS {HOST}...")
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(HOST, username=USER, password=PASS)
    
    sftp = client.open_sftp()
    remote_path = "/opt/aeroprojectvpn"
    
    # Ensure remote directory exists
    client.exec_command(f"mkdir -p {remote_path}/bot")
    
    local_bot_dir = "/home/terka/Рабочий стол/vpn/bot"
    files_to_upload = [
        "bot.py", "config.py", "database.py", "keyboards.py", 
        "panel_3xui.py", "subscription_api.py", "token_crypto.py", 
        "vpn_manager.py", "requirements.txt"
    ]
    
    for file in files_to_upload:
        local_file = os.path.join(local_bot_dir, file)
        remote_file = os.path.join(remote_path, "bot", file)
        if os.path.exists(local_file):
            print(f"Uploading {file}...")
            sftp.put(local_file, remote_file)
    
    sftp.close()
    
    print("Installing dependencies...")
    client.exec_command(f"pip3 install -r {remote_path}/bot/requirements.txt")
    
    print("Setting up systemd service...")
    service_content = f"""[Unit]
Description=AeroProject VPN Bot
After=network.target

[Service]
WorkingDirectory={remote_path}/bot
ExecStart=/usr/bin/python3 {remote_path}/bot/bot.py
Restart=always
User=root

[Install]
WantedBy=multi-user.target
"""
    api_service_content = f"""[Unit]
Description=AeroProject VPN Subscription API
After=network.target

[Service]
WorkingDirectory={remote_path}/bot
ExecStart=/usr/bin/python3 {remote_path}/bot/subscription_api.py
Restart=always
User=root

[Install]
WantedBy=multi-user.target
"""
    
    client.exec_command(f"echo '{service_content}' > /etc/systemd/system/aerovpn-bot.service")
    client.exec_command(f"echo '{api_service_content}' > /etc/systemd/system/aerovpn-api.service")
    
    print("Restarting services...")
    client.exec_command("systemctl daemon-reload")
    client.exec_command("systemctl enable aerovpn-bot aerovpn-api")
    client.exec_command("systemctl restart aerovpn-bot aerovpn-api")
    
    print("Deployment finished successfully!")
    client.close()

if __name__ == "__main__":
    deploy()
