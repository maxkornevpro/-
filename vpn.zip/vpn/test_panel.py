#!/usr/bin/env python3
import sys
sys.path.insert(0, "/opt/aeroprojectvpn")
from panel_3xui import get_germany_panel

panel = get_germany_panel()
if panel:
    print("LOGIN OK")
    inbounds = panel.get_inbounds()
    print("Inbounds:", len(inbounds) if inbounds else 0)
    for ib in (inbounds or []):
        print(f"  - {ib.get('remark', '')} port={ib.get('port', '')} protocol={ib.get('protocol', '')}")
else:
    print("LOGIN FAILED")
