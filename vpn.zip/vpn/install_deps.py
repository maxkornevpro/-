#!/usr/bin/env python3
"""Install dependencies on Sweden VPS using paramiko."""

import paramiko

HOST = "64.188.81.198"
USER = "root"
PASSWORD = "rqrecBUtBVNcKKX5"

def ssh_connect():
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(HOST, username=USER, password=PASSWORD, timeout=30)
    return client

def install_deps():
    print("📦 Installing dependencies on Sweden VPS...")
    client = ssh_connect()
    
    # Use apt to install python packages
    cmds = [
        "apt update",
        "apt install -y python3-pip python3-aiogram python3-flask",
        "pip3 install --break-system-packages paramiko",
        "cd /root/vpn_bot && python3 -c 'import bot; print(\"Bot OK\")'"
    ]
    
    for cmd in cmds:
        print(f"⚡ {cmd[:60]}...")
        stdin, stdout, stderr = client.exec_command(cmd)
        exit_status = stdout.channel.recv_exit_status()
        
        if exit_status == 0:
            print("✅ OK")
        else:
            err = stderr.read().decode()[:200]
            print(f"⚠️ {err}")
    
    # Start services
    print("\n🚀 Starting services...")
    client.exec_command("cd /root/vpn_bot && nohup python3 bot.py > bot.log 2>&1 &")
    client.exec_command("cd /root/vpn_bot && nohup python3 subscription_api.py > api.log 2>&1 &")
    
    # Check if running
    import time
    time.sleep(2)
    stdin, stdout, stderr = client.exec_command("ps aux | grep python3 | grep -v grep")
    processes = stdout.read().decode()
    print("\n📋 Running processes:")
    print(processes[:500])
    
    print("\n✅ Bot deployed and started!")
    print("🔗 Subscription URL: http://64.188.81.198:8080/sub/TOKEN")
    
    client.close()

if __name__ == "__main__":
    install_deps()
