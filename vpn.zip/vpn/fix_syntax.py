import re

with open(r"c:\Users\терка\Desktop\vpn\bot\bot.py", "r", encoding="utf-8") as f:
    content = f.read()

# I will find the @dp.callback_query(F.data.startswith("buy_")) up to the end of the file or next handler
start_idx = content.find('@dp.callback_query(F.data.startswith("buy_"))')
end_idx = content.find('@dp.callback_query(F.data == "my_key")')

if start_idx != -1 and end_idx != -1:
    content = content[:start_idx] + """@dp.callback_query(F.data.startswith("buy_"))
async def process_purchase(callback: CallbackQuery):
    \"\"\"Handle purchase selection.\"\"\"
    plan = callback.data.replace("buy_", "")
    user_id = callback.from_user.id
    username = callback.from_user.username
    
    price = PRICES.get(plan, 0)
    duration_text = {
        "1_month": "1 месяц",
        "6_months": "6 месяцев",
        "forever": "Навсегда"
    }.get(plan, plan)
    
    if cryptopay:
        try:
            invoice = await cryptopay.create_invoice(
                amount=price,
                fiat='RUB',
                currency_type='fiat',
                description=f"Оплата VPN ({duration_text})"
            )
            
            order_id = db.create_order(user_id, username, plan, price, invoice.invoice_id)
            
            kb = InlineKeyboardBuilder()
            kb.button(text="💳 Оплатить", url=invoice.bot_invoice_url)
            kb.button(text="🔄 Проверить оплату", callback_data=f"check_pay_{order_id}")
            kb.button(text="◀️ Назад", callback_data="buy")
            kb.adjust(1)
            
            await callback.message.edit_text(
                f"📦 <b>Оформление заказа</b>\\n\\n"
                f"📋 Тариф: {duration_text}\\n"
                f"💰 К оплате: {price}₽\\n\\n"
                f"Нажмите кнопку ниже для оплаты через CryptoBot:",
                reply_markup=kb.as_markup(),
                parse_mode=ParseMode.HTML
            )
            
            # Notify admins about pending order
            for admin_id in ADMIN_IDS:
                try:
                    await bot.send_message(admin_id, f"⏳ Пользователь @{username or user_id} создал счет на оплату {duration_text} через CryptoBot.", parse_mode=ParseMode.HTML)
                except:
                    pass
        except Exception as e:
            logger.error(f"CryptoPay error: {e}")
            await callback.answer("Ошибка создания платежа.", show_alert=True)
    else:
        # Create order without invoice_id
        order_id = db.create_order(user_id, username, plan, price)
        
        # Notify admin
        for admin_id in ADMIN_IDS:
            try:
                await bot.send_message(
                    admin_id,
                    f"🛒 <b>Новый заказ!</b>\\n\\n"
                    f"👤 Пользователь: @{username or user_id}\\n"
                    f"🆔 ID: <code>{user_id}</code>\\n"
                    f"📦 Тариф: {duration_text}\\n"
                    f"💰 Сумма: {price}₽\\n"
                    f"📋 Order ID: {order_id}\\n\\n"
                    f"❗️ Ожидает подтверждения оплаты",
                    reply_markup=confirm_payment_keyboard(order_id),
                    parse_mode=ParseMode.HTML
                )
            except Exception as e:
                logger.error(f"Failed to notify admin {admin_id}: {e}")
        
        await callback.message.edit_text(
            f"📦 <b>Заказ создан!</b>\\n\\n"
            f"📋 Тариф: {duration_text}\\n"
            f"💰 Сумма: {price}₽\\n\\n"
            f"💳 Для оплаты свяжитесь с администратором:\\n"
            f"{ADMIN_USERNAME}\\n\\n"
            f"📝 Укажите ваш ID: <code>{user_id}</code>\\n\\n"
            f"✅ После оплаты ключ будет сгенерирован автоматически",
            reply_markup=back_button(),
            parse_mode=ParseMode.HTML
        )

@dp.callback_query(F.data.startswith("check_pay_"))
async def check_crypto_payment(callback: CallbackQuery):
    if not cryptopay:
        await callback.answer("CryptoBot не настроен.", show_alert=True)
        return
        
    order_id = int(callback.data.replace("check_pay_", ""))
    db.cursor.execute("SELECT * FROM orders WHERE id = ?", (order_id,))
    order = db.cursor.fetchone()
    
    if not order or order[5] != 'pending':
        await callback.answer("❌ Заказ не найден или уже оплачен!", show_alert=True)
        return
        
    invoice_id = order[8] # index 8 is invoice_id
    if not invoice_id:
        await callback.answer("❌ Ошибка платежа.", show_alert=True)
        return
        
    try:
        invoices = await cryptopay.get_invoices(invoice_ids=invoice_id)
        if not invoices:
            await callback.answer("Счет не найден.", show_alert=True)
            return
            
        invoice = invoices[0]
        if invoice.status == 'paid':
            await callback.message.edit_text("⏳ Обработка платежа и выдача ключа...")
            
            user_id = order[1]
            duration_type = order[3]
            
            db.mark_order_paid(order_id)
            
            days = None
            if duration_type == "1_month":
                days = 30
            elif duration_type == "6_months":
                days = 180
            
            db.add_subscription(user_id, duration_type, order[4], days or 36500)
            
            # Cashback
            user_data = db.get_user(user_id)
            if user_data and user_data[6]:
                cashback = db.add_purchase_cashback(user_data[6], order[4])
                try:
                    await bot.send_message(user_data[6], f"🎉 <b>Кэшбэк получен!</b>\\nВаш реферал совершил покупку!\\n💰 +{cashback}₽ на баланс", parse_mode=ParseMode.HTML)
                except:
                    pass
            
            vpn = VPNManager(host=VPS_HOST, port=VPS_PORT)
            key_data = vpn.generate_vpn_key(user_id, days=days)
            
            db.add_vpn_key(
                user_id=user_id, uuid=key_data['uuid'], public_key=key_data['public_key'],
                private_key=key_data['private_key'], short_id=key_data['short_id'],
                expires_at=key_data['expires_at'], vless_link=key_data['vless_link'], server='sweden'
            )
            
            expiry_text = "♾️ Навсегда" if days is None else f"📅 {days} дней"
            sub_token = encrypt_user_id(user_id)
            sub_url = f"{API_BASE_URL}/sub/{sub_token}"
            
            await callback.message.edit_text(
                f"✅ <b>Оплата успешно получена!</b>\\n\\n"
                f"🎉 Тариф: {duration_type}\\n"
                f"⏰ Срок: {expiry_text}\\n"
                f"🌍 Анонимные серверы: 🇸🇪 Швеция + 🇪🇪 Эстония\\n\\n"
                f"🛡 <b>Ваша защищенная ссылка подписки:</b>\\n"
                f"<code>{sub_url}</code>\\n\\n"
                f"📋 <i>Нажмите на ссылку, чтобы скопировать</i>\\n\\n"
                f"📱 Вставьте ссылку в Happ или v2rayNG",
                parse_mode=ParseMode.HTML
            )
            
            for admin_id in ADMIN_IDS:
                try:
                    await bot.send_message(admin_id, f"💰 <b>Новая оплата (CryptoBot)!</b>\\nПользователь: @{order[2]}\\nСумма: {order[4]}₽", parse_mode=ParseMode.HTML)
                except:
                    pass
        else:
            await callback.answer("⏳ Оплата еще не поступила. Попробуйте через минуту.", show_alert=True)
    except Exception as e:
        logger.error(f"Check payment error: {e}")
        await callback.answer("Ошибка при проверке платежа.", show_alert=True)

""" + content[end_idx:]

with open(r"c:\Users\терка\Desktop\vpn\bot\bot.py", "w", encoding="utf-8") as f:
    f.write(content)

print("Fixed syntax errors in bot.py")
