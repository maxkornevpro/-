import paramiko
import sys

sys.stdout.reconfigure(encoding='utf-8')

SERVERS = [
    {"name": "Sweden", "host": "64.188.81.198", "password": "rqrecBUtBVNcKKX5"},
    {"name": "Estonia", "host": "95.85.249.79", "password": "FNvhSI1r4VVdbj7G"}
]

USER = "root"

print("="*50)
print("🔧 FINAL MTU FIX FOR MOBILE VPN")
print("="*50)

for server in SERVERS:
    print(f"\n📱 {server['name']} ({server['host']}):")
    
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(server['host'], username=USER, password=server['password'], timeout=30)
    
    # Set MTU to 1400 for mobile networks
    cmds = [
        # Set interface MTU to 1400 (allows mobile tunneling overhead)
        "ip link set dev ens3 mtu 1400 2>/dev/null || ip link set dev eth0 mtu 1400 2>/dev/null || echo 'Interface not found'",
        
        # Optimize TCP for mobile
        "sysctl -w net.ipv4.tcp_timestamps=0",
        "sysctl -w net.ipv4.tcp_sack=1", 
        "sysctl -w net.ipv4.tcp_window_scaling=1",
        "sysctl -w net.ipv4.tcp_congestion_control=bbr 2>/dev/null || sysctl -w net.ipv4.tcp_congestion_control=cubic",
        
        # Increase buffers for video streaming
        "sysctl -w net.core.rmem_max=16777216",
        "sysctl -w net.core.wmem_max=16777216",
        "sysctl -w net.ipv4.tcp_rmem='4096 87380 16777216'",
        "sysctl -w net.ipv4.tcp_wmem='4096 65536 16777216'",
        
        # Restart XRay to apply config changes
        "systemctl restart xray 2>/dev/null || service xray restart 2>/dev/null || pkill -f xray; sleep 2; nohup /usr/local/bin/xray -config /usr/local/etc/xray/config.json > /var/log/xray/restart.log 2>&1 &",
        
        # Wait and check
        "sleep 3",
        "ps aux | grep xray | grep -v grep | wc -l"
    ]
    
    for cmd in cmds:
        stdin, stdout, stderr = client.exec_command(cmd)
        output = stdout.read().decode().strip()
        error = stderr.read().decode().strip()
        
        if output:
            print(f"  {cmd[:50]:50} -> {output}")
        if error and 'nohup' not in cmd and '2>/dev/null' not in cmd:
            print(f"  ERR: {error[:100]}")
    
    # Verify MTU
    stdin, stdout, stderr = client.exec_command("ip addr show | grep mtu | head -2")
    print(f"\n  ✅ MTU status: {stdout.read().decode().strip()}")
    
    client.close()
    print(f"  ✅ {server['name']} optimized")

print("\n" + "="*50)
print("✅ MOBILE OPTIMIZATION COMPLETE")
print("="*50)
print("\n📝 Applied optimizations:")
print("   • Interface MTU: 1400 (was 1500)")
print("   • TCP timestamps: disabled")
print("   • TCP BBR: enabled")
print("   • Buffers: increased for video")
print("   • XRay: restarted with new settings")
print("\n📱 Test now on phone/TV:")
print("   YouTube and TikTok should load faster")
print("\n⚠️  If still slow, try:")
print("   1. Reconnect VPN on phone")
print("   2. Restart phone WiFi/4G")
print("   3. Try different server in app")
