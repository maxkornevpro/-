import paramiko
import sys
import time

sys.stdout.reconfigure(encoding='utf-8')

HOST = "64.188.81.198"
USER = "root"
PASSWORD = "rqrecBUtBVNcKKX5"

# Install aiocryptopay
print("Installing aiocryptopay...")
client = paramiko.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect(HOST, username=USER, password=PASSWORD, timeout=30)

stdin, stdout, stderr = client.exec_command("pip3 install --break-system-packages aiocryptopay 2>&1")
output = stdout.read().decode()
print(output[-500:])
client.close()
time.sleep(1)

# Restart bot
print("\nRestarting bot...")
client = paramiko.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect(HOST, username=USER, password=PASSWORD, timeout=30)

client.exec_command("pkill -f 'python3 bot.py' 2>/dev/null || true")
client.close()
time.sleep(2)

client = paramiko.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect(HOST, username=USER, password=PASSWORD, timeout=30)

stdin, stdout, stderr = client.exec_command("cd /root/vpn_bot && nohup python3 bot.py > bot.log 2>&1 &")
stdout.channel.recv_exit_status()
client.close()
time.sleep(2)

# Check status
print("\nChecking bot status...")
client = paramiko.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect(HOST, username=USER, password=PASSWORD, timeout=30)

stdin, stdout, stderr = client.exec_command("ps aux | grep bot.py | grep -v grep")
processes = stdout.read().decode().strip()
print("Running:", processes if processes else "None")

stdin, stdout, stderr = client.exec_command("tail -20 /root/vpn_bot/bot.log")
print("\nLog tail:")
print(stdout.read().decode())

client.close()
print("\nDone!")
