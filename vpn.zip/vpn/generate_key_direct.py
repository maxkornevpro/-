#!/usr/bin/env python3
"""Generate VLESS key directly via xray core + 3x-ui API."""
import subprocess, json, uuid, secrets, sys, requests, urllib3
urllib3.disable_warnings()

HOST = "2.26.54.63"
PANEL_PORT = 2053
ADMIN_USER = "admin"
ADMIN_PASS = "AeroDE_3xUi!2026"
INBOUND_ID = 1

BASE = f"https://{HOST}:{PANEL_PORT}"

# 1. Login to 3x-ui
s = requests.Session()
s.verify = False
r = s.post(f"{BASE}/login", data={"username":ADMIN_USER,"password":ADMIN_PASS}, timeout=15)
print("Login:", r.json().get("msg",""))
if not r.json().get("success"):
    print("Login failed")
    sys.exit(1)

# 2. Generate x25519 keys via xray core
xray = "/usr/local/x-ui/bin/xray-linux-amd64"
result = subprocess.run([xray, "x25519"], capture_output=True, text=True)
print("\nx25519 output:")
print(result.stdout)
lines = result.stdout.strip().splitlines()
priv = ""
pub = ""
for line in lines:
    if "Private" in line:
        priv = line.split(":")[-1].strip()
    if "Public" in line:
        pub = line.split(":")[-1].strip()

print(f"\nPrivate key: {priv}")
print(f"Public key:  {pub}")

# 3. Generate UUID
user_uuid = str(uuid.uuid4())
short_id = secrets.token_hex(8)
email = f"direct_{user_uuid[:8]}@aeroprojectvpn.com"

print(f"\nUUID:      {user_uuid}")
print(f"Short ID:  {short_id}")
print(f"Email:     {email}")

# 4. Add client to inbound via 3x-ui API
client_obj = {
    "id": user_uuid,
    "flow": "xtls-rprx-vision",
    "email": email,
    "limitIp": 0,
    "totalGB": 0,
    "expiryTime": 0,
    "enable": True,
    "tgId": "",
    "subId": ""
}

payload = {"id": INBOUND_ID, "settings": json.dumps({"clients": [client_obj]})}
r = s.post(f"{BASE}/panel/api/inbounds/addClient", json=payload, timeout=15)
print(f"\nAdd client: {r.status_code}")
print(r.json().get("msg", r.text[:200]))

# 5. Build VLESS link (for Germany)
public_key = "YBiczDZg0MEjEO4S_lQen4bwmOwWWhe_axoEOjka3jw"
sid = "e206aab7f52ddc9"
domain = "vpn.aeroproject.fun"

vless = (
    f"vless://{user_uuid}@{domain}?"
    f"flow=xtls-rprx-vision&encryption=none&security=reality&"
    f"sni=www.google.com&fp=chrome&pbk={public_key}&"
    f"sid={sid}&type=tcp&headerType=none#"
    f"AeroProjectVPN-{email}"
)

print(f"\n{'='*60}")
print("VLESS LINK:")
print(vless)
print(f"{'='*60}")
