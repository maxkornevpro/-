import paramiko

def execute_cmd(client, cmd):
    print(f"\n[+] Executing: {cmd}")
    client.exec_command(cmd)

client = paramiko.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
try:
    client.connect("64.188.81.198", username="root", password="rqrecBUtBVNcKKX5", timeout=10)
    
    # Remove systemd service files
    execute_cmd(client, "rm -f /etc/systemd/system/x-ui.service")
    execute_cmd(client, "rm -f /etc/systemd/system/3x-ui.service")
    execute_cmd(client, "systemctl daemon-reload")
    
    # Just in case x-ui bash script is installed in bin
    execute_cmd(client, "rm -f /usr/local/bin/x-ui")
    
    # Remove acme.sh to fully clean up
    execute_cmd(client, "rm -rf /root/.acme.sh")
    execute_cmd(client, "crontab -r") # Remove cron jobs installed by acme.sh or x-ui
    
except Exception as e:
    pass
finally:
    client.close()
