#!/usr/bin/env python3
import sqlite3
conn = sqlite3.connect('/opt/aeroprojectvpn/vpn_bot.db')
c = conn.cursor()

# Check if user exists
c.execute("SELECT user_id, trial_used FROM users WHERE user_id = 1246190987")
user = c.fetchone()
print('Before:', user)

if user:
    c.execute("UPDATE users SET trial_used = 0 WHERE user_id = 1246190987")
    conn.commit()
    print('Trial reset for user 1246190987')
else:
    print('User not found in DB')

# Also clear any expired keys/subscriptions for testing
c.execute("DELETE FROM vpn_keys WHERE user_id = 1246190987")
c.execute("DELETE FROM subscriptions WHERE user_id = 1246190987")
c.execute("DELETE FROM orders WHERE user_id = 1246190987")
conn.commit()
print('Cleared keys, subs, orders for user 1246190987')

conn.close()
