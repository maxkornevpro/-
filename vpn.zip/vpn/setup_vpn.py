#!/usr/bin/env python3
"""SSH client to setup Xray VLESS VPN on VPS."""

import paramiko
import time
import uuid
import json
import sys

# Server details
HOST = "64.188.81.198"
USER = "root"
PASSWORD = "rqrecBUtBVNcKKX5"
PORT = 443  # VLESS port

def ssh_connect():
    """Connect to SSH server."""
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(HOST, username=USER, password=PASSWORD, timeout=30)
    return client

def install_xray(client):
    """Install Xray-core."""
    print("Installing Xray-core...")
    cmd = "bash <(curl -L https://github.com/XTLS/Xray-install/raw/main/install-release.sh) install"
    stdin, stdout, stderr = client.exec_command(cmd)
    
    # Wait for command to complete
    exit_status = stdout.channel.recv_exit_status()
    if exit_status != 0:
        err = stderr.read().decode()
        print(f"Install error: {err}")
        return False
    
    output = stdout.read().decode()
    print(output)
    return True

def generate_config():
    """Generate Xray server config with VLESS."""
    user_uuid = str(uuid.uuid4())
    
    config = {
        "log": {"loglevel": "warning"},
        "inbounds": [
            {
                "port": PORT,
                "protocol": "vless",
                "settings": {
                    "clients": [
                        {
                            "id": user_uuid,
                            "flow": "xtls-rprx-vision"
                        }
                    ],
                    "decryption": "none"
                },
                "streamSettings": {
                    "network": "tcp",
                    "security": "reality",
                    "realitySettings": {
                        "dest": "www.google.com:443",
                        "serverNames": ["www.google.com"],
                        "privateKey": "",  # Will generate
                        "shortIds": [""]
                    }
                }
            }
        ],
        "outbounds": [
            {"protocol": "freedom", "tag": "direct"}
        ]
    }
    return config, user_uuid

def setup_reality_keys(client):
    """Generate Reality keys."""
    print("Generating Reality keys...")
    stdin, stdout, stderr = client.exec_command("xray x25519")
    output = stdout.read().decode()
    
    private_key = None
    public_key = None
    
    for line in output.split('\n'):
        if 'Private' in line:
            private_key = line.split(':')[1].strip()
        if 'Public' in line:
            public_key = line.split(':')[1].strip()
    
    return private_key, public_key

def get_server_ip():
    """Get server public IP."""
    return HOST

def main():
    print(f"Connecting to {HOST}...")
    
    try:
        client = ssh_connect()
        print("Connected!")
        
        # Install Xray
        if not install_xray(client):
            print("Failed to install Xray")
            return
        
        print("Xray installed successfully!")
        
        # Generate Reality keys
        private_key, public_key = setup_reality_keys(client)
        print(f"Reality Private Key: {private_key}")
        print(f"Reality Public Key: {public_key}")
        
        # Generate UUID
        user_uuid = str(uuid.uuid4())
        short_id = "8f7c67"  # Random short ID
        
        # Create config
        config = {
            "log": {"loglevel": "warning"},
            "inbounds": [
                {
                    "listen": "0.0.0.0",
                    "port": PORT,
                    "protocol": "vless",
                    "settings": {
                        "clients": [
                            {
                                "id": user_uuid,
                                "flow": "xtls-rprx-vision"
                            }
                        ],
                        "decryption": "none"
                    },
                    "streamSettings": {
                        "network": "tcp",
                        "security": "reality",
                        "realitySettings": {
                            "dest": "www.google.com:443",
                            "serverNames": ["www.google.com", "google.com"],
                            "privateKey": private_key,
                            "shortIds": [short_id]
                        }
                    },
                    "sniffing": {
                        "enabled": True,
                        "destOverride": ["http", "tls"]
                    }
                }
            ],
            "outbounds": [
                {"protocol": "freedom", "tag": "direct"}
            ]
        }
        
        # Write config to server
        config_json = json.dumps(config, indent=2)
        cmd = f"echo '{config_json}' > /usr/local/etc/xray/config.json"
        stdin, stdout, stderr = client.exec_command(cmd)
        
        # Restart Xray
        print("Restarting Xray...")
        client.exec_command("systemctl restart xray")
        client.exec_command("systemctl enable xray")
        
        # Check status
        stdin, stdout, stderr = client.exec_command("systemctl status xray --no-pager")
        status = stdout.read().decode()
        print(status[:500])
        
        # Generate client link
        server_ip = get_server_ip()
        vless_link = f"vless://{user_uuid}@{server_ip}:{PORT}?flow=xtls-rprx-vision&encryption=none&security=reality&sni=www.google.com&fp=chrome&pbk={public_key}&sid={short_id}&type=tcp&headerType=none#VPN-Sweden"
        
        print("\n" + "="*60)
        print("SETUP COMPLETE!")
        print("="*60)
        print(f"\nServer IP: {server_ip}")
        print(f"Port: {PORT}")
        print(f"UUID: {user_uuid}")
        print(f"Flow: xtls-rprx-vision")
        print(f"Security: Reality")
        print(f"Public Key: {public_key}")
        print(f"Short ID: {short_id}")
        print(f"SNI: www.google.com")
        print(f"\nVLESS Link:\n{vless_link}")
        print("\n" + "="*60)
        print("\nCopy the VLESS link above and import it into your client:")
        print("- Nekoray (Windows/Linux)")
        print("- v2rayNG (Android)")  
        print("- Streisand (iOS)")
        print("- V2rayN (Windows)")
        
        client.close()
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
