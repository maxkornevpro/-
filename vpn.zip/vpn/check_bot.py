import paramiko
import sys

sys.stdout.reconfigure(encoding='utf-8')

HOST = "64.188.81.198"
USER = "root"
PASSWORD = "rqrecBUtBVNcKKX5"

print(f"Connecting to {HOST}...")
client = paramiko.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect(HOST, username=USER, password=PASSWORD, timeout=30)

print("Checking bot status...")
stdin, stdout, stderr = client.exec_command("ps aux | grep bot.py | grep -v grep")
processes = stdout.read().decode().strip()
print("Processes:", processes if processes else "No bot processes found")

print("\n--- Bot log (last 50 lines) ---")
stdin, stdout, stderr = client.exec_command("tail -50 /root/vpn_bot/bot.log")
print(stdout.read().decode())

err = stderr.read().decode()
if err:
    print("Errors:", err)

client.close()
print("Done!")
