#!/usr/bin/env python3
"""Fix Xray port conflict."""

import paramiko
import json
import time

HOST = "64.188.81.198"
USER = "root"
PASSWORD = "rqrecBUtBVNcKKX5"
PORT = 8443  # Changed from 443 to avoid nginx conflict

def ssh_connect():
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(HOST, username=USER, password=PASSWORD, timeout=30)
    return client

def main():
    client = ssh_connect()
    
    # Config values from before
    user_uuid = "50bd836c-60b0-432a-b44f-7c052ef0e677"
    private_key = "gHc4p7EMAOpuC4hNJ_1mtKTZavkbbKWIQ-Coyc3s2UI"
    public_key = "VGOz4MRejC-P3_CtfRasF1Tpq52vh1LLKxozmRK_wAA"
    short_id = "8f7c67"
    
    # Create config with new port
    config = {
        "log": {"loglevel": "warning"},
        "inbounds": [
            {
                "listen": "0.0.0.0",
                "port": PORT,
                "protocol": "vless",
                "settings": {
                    "clients": [
                        {
                            "id": user_uuid,
                            "flow": "xtls-rprx-vision"
                        }
                    ],
                    "decryption": "none"
                },
                "streamSettings": {
                    "network": "tcp",
                    "security": "reality",
                    "realitySettings": {
                        "dest": "www.google.com:443",
                        "serverNames": ["www.google.com", "google.com"],
                        "privateKey": private_key,
                        "shortIds": [short_id]
                    }
                },
                "sniffing": {
                    "enabled": True,
                    "destOverride": ["http", "tls"]
                }
            }
        ],
        "outbounds": [
            {"protocol": "freedom", "tag": "direct"}
        ]
    }
    
    # Write config using heredoc
    config_json = json.dumps(config, indent=2)
    cmd = f"cat > /usr/local/etc/xray/config.json << 'EOF'\n{config_json}\nEOF"
    stdin, stdout, stderr = client.exec_command(cmd)
    
    # Stop nginx or change port
    print("Stopping nginx to free up resources...")
    client.exec_command("systemctl stop nginx")
    client.exec_command("systemctl disable nginx")
    
    # Kill any existing Xray processes
    client.exec_command("pkill -f xray")
    time.sleep(1)
    
    # Reset failed state
    client.exec_command("systemctl reset-failed xray")
    
    # Start Xray
    print("Starting Xray on port", PORT)
    client.exec_command("systemctl restart xray")
    client.exec_command("systemctl enable xray")
    time.sleep(2)
    
    # Check status
    stdin, stdout, stderr = client.exec_command("systemctl status xray --no-pager")
    status = stdout.read().decode()
    print("\n--- Service Status ---")
    print(status[:600])
    
    # Check if port is listening
    stdin, stdout, stderr = client.exec_command(f"ss -tlnp | grep {PORT}")
    listening = stdout.read().decode()
    print(f"\n--- Port {PORT} ---")
    print(listening if listening else "Not listening!")
    
    # Check logs
    stdin, stdout, stderr = client.exec_command("cat /var/log/xray/error.log | tail -10")
    logs = stdout.read().decode()
    print("\n--- Recent logs ---")
    print(logs)
    
    # Generate VLESS link
    vless_link = f"vless://{user_uuid}@{HOST}:{PORT}?flow=xtls-rprx-vision&encryption=none&security=reality&sni=www.google.com&fp=chrome&pbk={public_key}&sid={short_id}&type=tcp&headerType=none#VPN-Sweden"
    
    print("\n" + "="*70)
    print("VPN SETUP COMPLETE!")
    print("="*70)
    print(f"\nServer: {HOST}")
    print(f"Port: {PORT}")
    print(f"UUID: {user_uuid}")
    print(f"Flow: xtls-rprx-vision")
    print(f"Security: Reality")
    print(f"Public Key: {public_key}")
    print(f"Short ID: {short_id}")
    print(f"SNI: www.google.com")
    print(f"\nVLESS Link (скопируй этот линк полностью):")
    print("-"*70)
    print(vless_link)
    print("-"*70)
    print("\nИспользуй этот линк в клиентах:")
    print("- Nekoray / Nekobox (Windows/Android)")
    print("- v2rayNG (Android)")
    print("- Streisand (iOS)")
    print("- V2rayN (Windows)")
    print("\nИмпортируй линк: скопируй и вставь в клиент, или сканируй QR-код.")
    print("="*70)
    
    client.close()

if __name__ == "__main__":
    main()
