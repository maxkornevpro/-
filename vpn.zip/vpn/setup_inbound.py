#!/usr/bin/env python3
import requests, json, secrets, base64, sys

HOST = "2.26.54.63"
PORT = 2053
USERNAME = "admin"
PASSWORD = "AeroDE_3xUi!2026"

BASE_URL = f"https://{HOST}:{PORT}"

session = requests.Session()
session.trust_env = False

# Login
r = session.post(f"{BASE_URL}/login", data={"username": USERNAME, "password": PASSWORD}, verify=False, timeout=20)
print("Login:", r.status_code, r.text[:200])
if not r.json().get("success"):
    print("Login failed")
    sys.exit(1)

# Generate x25519 keys
import subprocess
result = subprocess.run(["/usr/local/x-ui/bin/xray-linux-amd64", "x25519"], capture_output=True, text=True)
print("x25519 output:", result.stdout)
lines = result.stdout.strip().splitlines()
private_key = ""
public_key = ""
for line in lines:
    if "Private" in line:
        private_key = line.split(":")[-1].strip()
    if "Public" in line:
        public_key = line.split(":")[-1].strip()

print(f"Private: {private_key}")
print(f"Public: {public_key}")

short_id = secrets.token_hex(8)

# Create VLESS Reality inbound
payload = {
    "up": 0,
    "down": 0,
    "total": 0,
    "remark": "VLESS-443",
    "enable": True,
    "expiryTime": 0,
    "listen": "",
    "port": 443,
    "protocol": "vless",
    "settings": json.dumps({
        "clients": [],
        "decryption": "none",
        "fallbacks": []
    }),
    "streamSettings": json.dumps({
        "network": "tcp",
        "security": "reality",
        "externalProxy": [],
        "realitySettings": {
            "show": False,
            "xver": 0,
            "dest": "www.google.com:443",
            "serverNames": ["www.google.com", "www.youtube.com"],
            "privateKey": private_key,
            "minClient": "",
            "maxClient": "",
            "maxTimediff": 0,
            "shortIds": [short_id],
            "settings": {
                "publicKey": public_key,
                "fingerprint": "chrome",
                "serverName": "",
                "spiderX": "/"
            }
        },
        "tcpSettings": {
            "acceptProxyProtocol": False,
            "header": {
                "type": "none"
            }
        }
    }),
    "sniffing": json.dumps({
        "enabled": True,
        "destOverride": ["http", "tls", "quic"],
        "metadataOnly": False,
        "routeOnly": False
    })
}

r = session.post(f"{BASE_URL}/panel/api/inbounds/add", json=payload, verify=False, timeout=30)
print("Add inbound:", r.status_code, r.text[:500])

if r.json().get("success"):
    print(f"\nSUCCESS! Public key: {public_key}")
    print(f"Short ID: {short_id}")
else:
    print("Failed to create inbound")
