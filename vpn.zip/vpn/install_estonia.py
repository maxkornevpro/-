import paramiko
import time

print("Connecting to Estonia...")
client = paramiko.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect('95.85.249.79', username='root', password='FNvhSI1r4VVdbj7G', timeout=30)

print("Installing 3x-ui...")

# Download install script
stdin, stdout, stderr = client.exec_command("curl -Lso install.sh https://raw.githubusercontent.com/mhsanaei/3x-ui/master/install.sh")
stdout.channel.recv_exit_status()

# Run with auto-answers
stdin, stdout, stderr = client.exec_command("bash install.sh", timeout=300)

# Provide answers to prompts
stdin.write("y\n")
stdin.flush()
time.sleep(1)
stdin.write("y\n") 
stdin.flush()
time.sleep(1)
stdin.write("y\n")
stdin.flush()

# Wait for completion
exit_code = stdout.channel.recv_exit_status()
print(f"Install exit code: {exit_code}")

# Cleanup
client.exec_command("rm -f install.sh")

# Check status
stdin, stdout, stderr = client.exec_command("systemctl is-active x-ui")
status = stdout.read().decode().strip()
print(f"3x-ui status: {status}")

client.close()
print("Done!")
