"""
Production setup for AeroProjectVPN.

1. Moves both VPS boxes to 3x-ui managed VLESS Reality on port 8443.
2. Deploys the bot and subscription API to Sweden.
3. Starts everything via systemd.
"""

from __future__ import annotations

import json
import posixpath
import textwrap
import time
from pathlib import Path

import paramiko
import requests


BASE_DIR = Path(__file__).resolve().parent
BOT_DIR = BASE_DIR / "bot"
REMOTE_APP_DIR = "/opt/aeroprojectvpn"

SERVERS = [
    {
        "name": "sweden",
        "host": "64.188.81.198",
        "user": "root",
        "password": "rqrecBUtBVNcKKX5",
        "panel_port": 2053,
        "panel_username": "admin",
        "panel_password": "AeroSE_3xUi!2026",
    },
    {
        "name": "estonia",
        "host": "95.85.249.79",
        "user": "root",
        "password": "FNvhSI1r4VVdbj7G",
        "panel_port": 2053,
        "panel_username": "admin",
        "panel_password": "AeroEE_3xUi!2026",
    },
]

BOT_FILES = [
    "bot.py",
    "config.py",
    "database.py",
    "keyboards.py",
    "panel_3xui.py",
    "requirements.txt",
    "subscription_api.py",
    "token_crypto.py",
    "vpn_manager.py",
    "vpn_bot.db",
]


def ssh_connect(server: dict) -> paramiko.SSHClient:
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(server["host"], username=server["user"], password=server["password"], timeout=20)
    return client


def run(client: paramiko.SSHClient, command: str, timeout: int = 120) -> tuple[int, str, str]:
    stdin, stdout, stderr = client.exec_command(command, timeout=timeout)
    exit_code = stdout.channel.recv_exit_status()
    out = stdout.read().decode(errors="ignore")
    err = stderr.read().decode(errors="ignore")
    return exit_code, out, err


def upload_text(sftp: paramiko.SFTPClient, remote_path: str, content: str) -> None:
    with sftp.file(remote_path, "w") as remote_file:
        remote_file.write(content)


def ensure_3xui_installed(client: paramiko.SSHClient, server: dict) -> None:
    code, _, _ = run(client, "test -x /usr/local/x-ui/x-ui")
    if code == 0:
        return

    install_command = textwrap.dedent(
        f"""\
        bash <(curl -Ls https://raw.githubusercontent.com/mhsanaei/3x-ui/master/install.sh) <<'EOF'
        y
        {server["panel_username"]}
        {server["panel_password"]}
        {server["panel_port"]}
        EOF
        """
    )
    code, out, err = run(client, install_command, timeout=600)
    if code != 0:
        raise RuntimeError(f"3x-ui install failed on {server['name']}: {out}\n{err}")


def set_panel_settings(client: paramiko.SSHClient, server: dict) -> None:
    commands = [
        f"/usr/local/x-ui/x-ui setting -username '{server['panel_username']}'",
        f"/usr/local/x-ui/x-ui setting -password '{server['panel_password']}'",
        f"/usr/local/x-ui/x-ui setting -port {server['panel_port']}",
        "/usr/local/x-ui/x-ui setting -listenIP 0.0.0.0",
        "systemctl enable x-ui",
    ]
    for command in commands:
        code, out, err = run(client, command, timeout=60)
        if code != 0:
            raise RuntimeError(f"Panel config failed on {server['name']}: {command}\n{out}\n{err}")


def read_json(client: paramiko.SSHClient, path: str) -> dict:
    code, out, err = run(client, f"cat {path}", timeout=60)
    if code != 0:
        raise RuntimeError(f"Failed to read {path}: {err}")
    return json.loads(out)


def ensure_inbound_in_database(client: paramiko.SSHClient, server: dict) -> None:
    xray_config = read_json(client, "/usr/local/etc/xray/config.json")
    inbound = xray_config["inbounds"][0]

    settings_obj = inbound.get("settings", {})
    for client_item in settings_obj.get("clients", []):
        client_item.setdefault("email", f"{client_item['id']}@{server['name']}.local")
        client_item.setdefault("limitIp", 0)
        client_item.setdefault("totalGB", 0)
        client_item.setdefault("expiryTime", 0)
        client_item.setdefault("enable", True)
        client_item.setdefault("tgId", "")
        client_item.setdefault("subId", "")
        client_item.setdefault("reset", 0)

    stream_settings = inbound.get("streamSettings", {})
    reality_settings = stream_settings.setdefault("realitySettings", {})
    if "publicKey" not in reality_settings:
        private_key = reality_settings["privateKey"]
        code, out, err = run(client, f"xray x25519 -i '{private_key}'", timeout=60)
        if code != 0:
            raise RuntimeError(f"Could not derive public key on {server['name']}: {err}")
        for line in out.splitlines():
            if "Password (PublicKey)" in line:
                reality_settings["publicKey"] = line.split(":", 1)[1].strip()
                break

    sniffing = inbound.get(
        "sniffing",
        {"enabled": True, "destOverride": ["http", "tls", "quic"], "metadataOnly": False},
    )
    payload = {
        "remark": f"{server['name']}-reality-8443",
        "listen": inbound.get("listen", "0.0.0.0"),
        "port": inbound["port"],
        "protocol": inbound["protocol"],
        "settings": json.dumps(settings_obj, separators=(",", ":")),
        "stream_settings": json.dumps(stream_settings, separators=(",", ":")),
        "tag": inbound.get("tag") or f"vless-reality-{server['name']}",
        "sniffing": json.dumps(sniffing, separators=(",", ":")),
    }

    script = textwrap.dedent(
        f"""\
        python3 - <<'PY'
        import json
        import sqlite3

        payload = json.loads({json.dumps(json.dumps(payload))})
        conn = sqlite3.connect('/etc/x-ui/x-ui.db')
        cur = conn.cursor()
        cur.execute('SELECT id FROM inbounds WHERE port = ?', (payload['port'],))
        row = cur.fetchone()
        values = (
            1, 0, 0, 0, 0, payload['remark'], 1, 0, 'never', 0, payload['listen'], payload['port'],
            payload['protocol'], payload['settings'], payload['stream_settings'], payload['tag'], payload['sniffing']
        )
        if row:
            cur.execute(
                '''
                UPDATE inbounds
                SET user_id=?, up=?, down=?, total=?, all_time=?, remark=?, enable=?, expiry_time=?,
                    traffic_reset=?, last_traffic_reset_time=?, listen=?, port=?, protocol=?, settings=?,
                    stream_settings=?, tag=?, sniffing=?
                WHERE id=?
                ''',
                values + (row[0],)
            )
        else:
            cur.execute(
                '''
                INSERT INTO inbounds (
                    user_id, up, down, total, all_time, remark, enable, expiry_time, traffic_reset,
                    last_traffic_reset_time, listen, port, protocol, settings, stream_settings, tag, sniffing
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''',
                values
            )
        conn.commit()
        conn.close()
        print('ok')
        PY
        """
    )
    code, out, err = run(client, script, timeout=120)
    if code != 0 or "ok" not in out:
        raise RuntimeError(f"DB sync failed on {server['name']}: {out}\n{err}")


def activate_panel_managed_xray(client: paramiko.SSHClient, server: dict) -> None:
    commands = [
        "cp /usr/local/etc/xray/config.json /usr/local/etc/xray/config.json.backup.$(date +%s)",
        "systemctl stop xray || true",
        "systemctl disable xray || true",
        "systemctl restart x-ui",
        f"ufw allow {server['panel_port']}/tcp >/dev/null 2>&1 || true",
        "ufw allow 8443/tcp >/dev/null 2>&1 || true",
    ]
    for command in commands:
        code, out, err = run(client, command, timeout=180)
        if code != 0:
            raise RuntimeError(f"Activation failed on {server['name']}: {command}\n{out}\n{err}")


def verify_panel(server: dict) -> None:
    session = requests.Session()
    session.trust_env = False
    base_url = f"http://{server['host']}:{server['panel_port']}"
    login = session.post(
        f"{base_url}/login",
        data={"username": server["panel_username"], "password": server["panel_password"]},
        timeout=20,
    )
    login.raise_for_status()
    if not login.json().get("success"):
        raise RuntimeError(f"Panel login failed on {server['name']}")

    response = session.get(f"{base_url}/panel/api/inbounds/list", timeout=20)
    response.raise_for_status()
    data = response.json()
    if not data.get("success"):
        raise RuntimeError(f"Inbound list failed on {server['name']}")
    if not any(inbound.get("port") == 8443 for inbound in data.get("obj", [])):
        raise RuntimeError(f"8443 inbound missing on {server['name']}")


def deploy_bot_to_sweden(server: dict) -> None:
    client = ssh_connect(server)
    try:
        run(client, f"mkdir -p {REMOTE_APP_DIR}", timeout=30)
        sftp = client.open_sftp()
        for filename in BOT_FILES:
            sftp.put(str(BOT_DIR / filename), posixpath.join(REMOTE_APP_DIR, filename))

        bot_service = textwrap.dedent(
            f"""\
            [Unit]
            Description=AeroProjectVPN Telegram bot
            After=network.target

            [Service]
            Type=simple
            WorkingDirectory={REMOTE_APP_DIR}
            ExecStart=/usr/bin/python3 {REMOTE_APP_DIR}/bot.py
            Restart=always
            RestartSec=5
            User=root

            [Install]
            WantedBy=multi-user.target
            """
        )
        api_service = textwrap.dedent(
            f"""\
            [Unit]
            Description=AeroProjectVPN subscription API
            After=network.target

            [Service]
            Type=simple
            WorkingDirectory={REMOTE_APP_DIR}
            ExecStart=/usr/bin/python3 {REMOTE_APP_DIR}/subscription_api.py
            Restart=always
            RestartSec=5
            User=root

            [Install]
            WantedBy=multi-user.target
            """
        )
        upload_text(sftp, "/etc/systemd/system/aerovpn-bot.service", bot_service)
        upload_text(sftp, "/etc/systemd/system/aerovpn-subscription-api.service", api_service)
        sftp.close()

        commands = [
            "apt-get update",
            "apt-get install -y python3-pip",
            f"python3 -m pip install --break-system-packages -r {REMOTE_APP_DIR}/requirements.txt",
            "systemctl stop bot || true",
            "pkill -f '/root/vpn_bot/bot.py' || true",
            "pkill -f 'subscription_api.py' || true",
            "systemctl daemon-reload",
            "systemctl enable aerovpn-bot.service aerovpn-subscription-api.service",
            "systemctl restart aerovpn-bot.service",
            "systemctl restart aerovpn-subscription-api.service",
            "ufw allow 8080/tcp >/dev/null 2>&1 || true",
        ]
        for command in commands:
            code, out, err = run(client, command, timeout=600)
            if code != 0:
                raise RuntimeError(f"Deploy failed: {command}\n{out}\n{err}")
    finally:
        client.close()


def verify_sweden_services(server: dict) -> None:
    client = ssh_connect(server)
    try:
        for command in [
            "systemctl is-active aerovpn-bot.service",
            "systemctl is-active aerovpn-subscription-api.service",
            "ss -tulpn | grep ':8080 ' || true",
            "ss -tulpn | grep ':8443 ' || true",
        ]:
            code, out, err = run(client, command, timeout=30)
            print((out or err).strip())
    finally:
        client.close()


def main() -> None:
    for server in SERVERS:
        print(f"[{server['name']}] fixing 3x-ui")
        client = ssh_connect(server)
        try:
            ensure_3xui_installed(client, server)
            set_panel_settings(client, server)
            ensure_inbound_in_database(client, server)
            activate_panel_managed_xray(client, server)
        finally:
            client.close()

        time.sleep(5)
        verify_panel(server)

    print("[sweden] deploying bot and API")
    deploy_bot_to_sweden(SERVERS[0])
    verify_sweden_services(SERVERS[0])
    print("All done.")


if __name__ == "__main__":
    main()
