import paramiko

def execute_cmd(client, cmd):
    print(f"\n[+] Executing: {cmd}")
    stdin, stdout, stderr = client.exec_command(cmd)
    
    out = stdout.read().decode('utf-8', errors='ignore')
    err = stderr.read().decode('utf-8', errors='ignore')
    
    if out.strip():
        print(out.encode('ascii', 'replace').decode('ascii')[:1000])
    if err.strip():
        print(f"ERROR: {err.encode('ascii', 'replace').decode('ascii')[:1000]}")

client = paramiko.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
try:
    print("Connecting to 64.188.81.198...")
    client.connect("64.188.81.198", username="root", password="rqrecBUtBVNcKKX5", timeout=10)
    print("Connected successfully!")
    
    # 1. Stop and remove PM2 processes
    execute_cmd(client, "if command -v pm2 >/dev/null; then pm2 kill; fi")
    
    # 2. Stop and remove all Docker containers, networks, volumes (bots, marzban, etc.)
    execute_cmd(client, "if command -v docker >/dev/null; then docker stop $(docker ps -aq); docker rm -f $(docker ps -aq); docker network prune -f; docker volume prune -f; fi")
    
    # 3. Stop and disable VPN cores and Web Servers
    services_to_stop = ["x-ui", "3x-ui", "marzban", "nginx", "apache2"]
    for srv in services_to_stop:
        execute_cmd(client, f"systemctl stop {srv}; systemctl disable {srv}")
        
    # 4. Remove VPN core directories
    execute_cmd(client, "rm -rf /usr/local/x-ui/ /etc/x-ui/ /usr/local/3x-ui/ /etc/3x-ui/ /opt/marzban/ /var/lib/marzban/")
    
    # 5. Remove web directories
    execute_cmd(client, "rm -rf /var/www/html/* /etc/nginx/sites-enabled/* /etc/nginx/sites-available/*")
    
    # 6. Remove bot and site files in /root/
    execute_cmd(client, "rm -rf /root/aero-api /root/aeroproject /root/aero_users.db /root/aeroweb /root/deploy.sh /root/vpn_bot /root/.pm2 /root/cert /root/test.db /root/Aero.db")
    
    # 7. Check if anything is left
    execute_cmd(client, "ls -la /root")
    
    # 8. Reload daemon
    execute_cmd(client, "systemctl daemon-reload")
    
    print("\nCleanup completed.")
    
except Exception as e:
    print(f"Error: {e}")
finally:
    client.close()
