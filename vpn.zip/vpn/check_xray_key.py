#!/usr/bin/env python3
"""Check and fix Xray public key."""
import paramiko
import json

HOST = "64.188.81.198"
USER = "root"
PASSWORD = "rqrecBUtBVNcKKX5"

def check_and_fix():
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(HOST, username=USER, password=PASSWORD, timeout=30)
    
    # Get config
    print("Reading Xray config...")
    stdin, stdout, stderr = client.exec_command("cat /usr/local/etc/xray/config.json")
    config = json.loads(stdout.read().decode())
    
    reality_settings = config['inbounds'][0]['streamSettings']['realitySettings']
    private_key = reality_settings['privateKey']
    
    print(f"Private key: {private_key[:30]}...")
    print(f"Short ID: {reality_settings['shortIds']}")
    print(f"Dest: {reality_settings['dest']}")
    print(f"ServerNames: {reality_settings['serverNames']}")
    
    # Generate public key using xray
    print("\nGenerating public key from private key...")
    stdin, stdout, stderr = client.exec_command(f"/usr/local/bin/xray x25519 --input='{private_key}'")
    x25519_output = stdout.read().decode()
    print(f"x25519 output:\n{x25519_output}")
    
    # Extract public key
    for line in x25519_output.split('\n'):
        if 'Public key:' in line:
            expected_public_key = line.split('Public key:')[1].strip()
            print(f"\n✅ Expected Public Key: {expected_public_key}")
            break
    else:
        print("❌ Could not generate public key")
        expected_public_key = None
    
    # Check current config public key (should match)
    if expected_public_key:
        print(f"\nCompare with config:")
        print(f"  Generated: {expected_public_key}")
        print(f"  Config should use this public key in client configs")
    
    client.close()

if __name__ == "__main__":
    check_and_fix()
