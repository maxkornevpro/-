#!/usr/bin/env python3
"""Setup Flask and start API."""
import paramiko
import time

HOST = "64.188.81.198"
USER = "root"
PASSWORD = "rqrecBUtBVNcKKX5"

def setup():
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(HOST, username=USER, password=PASSWORD, timeout=30)
    
    print("Creating virtual environment...")
    stdin, stdout, stderr = client.exec_command("cd /root/vpn_bot && python3 -m venv venv")
    stdout.channel.recv_exit_status()
    
    print("Installing Flask...")
    stdin, stdout, stderr = client.exec_command("cd /root/vpn_bot && venv/bin/pip install flask")
    
    # Wait
    for i in range(15):
        time.sleep(2)
        stdin, stdout, stderr = client.exec_command("ps aux | grep pip | grep -v grep | grep -v grep")
        if not stdout.read().decode().strip():
            print(f"Done after {i+1} checks")
            break
    
    print("Testing Flask...")
    stdin, stdout, stderr = client.exec_command(
        "cd /root/vpn_bot && venv/bin/python -c 'from flask import Flask; print(\"OK\")'"
    )
    result = stdout.read().decode().strip()
    print(f"Result: {result}")
    
    if result == "OK":
        print("Starting API...")
        client.exec_command("pkill -f subscription_api.py")
        time.sleep(1)
        client.exec_command(
            "cd /root/vpn_bot && nohup venv/bin/python subscription_api.py > api.log 2>&1 &"
        )
        time.sleep(3)
        
        stdin, stdout, stderr = client.exec_command(
            "ps aux | grep subscription_api | grep -v grep"
        )
        if "subscription_api" in stdout.read().decode():
            print("✅ API is running!")
        else:
            print("❌ API failed to start")
            stdin, stdout, stderr = client.exec_command(
                "cat /root/vpn_bot/api.log | tail -5"
            )
            print("Log:", stdout.read().decode())
    else:
        print("❌ Flask not working")
    
    client.close()

if __name__ == "__main__":
    setup()
