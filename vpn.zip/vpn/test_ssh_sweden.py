import paramiko

client = paramiko.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
try:
    print("Connecting to 64.188.81.198...")
    client.connect("64.188.81.198", username="root", password="rqrecBUtBVNcKKX5", timeout=30)
    print("Connected successfully!")
    stdin, stdout, stderr = client.exec_command("uname -a")
    print(stdout.read().decode())
except Exception as e:
    print(f"Error: {e}")
finally:
    client.close()
