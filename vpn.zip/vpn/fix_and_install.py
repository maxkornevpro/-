import paramiko
import time

# Fix Sweden - make panel listen on all interfaces
print("=== Fixing Sweden panel ===")
client = paramiko.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect('64.188.81.198', username='root', password='rqrecBUtBVNcKKX5', timeout=30)

print("1. Stopping x-ui...")
client.exec_command('systemctl stop x-ui')
time.sleep(2)

print("2. Updating config to listen on 0.0.0.0...")
client.exec_command("sed -i 's/127.0.0.1/0.0.0.0/g' /usr/local/x-ui/bin/config.json")

print("3. Starting x-ui...")
client.exec_command('systemctl start x-ui')
time.sleep(3)

print("4. Checking...")
stdin, stdout, stderr = client.exec_command('ss -tlnp | grep 62789')
result = stdout.read().decode().strip()
print(f"Port status: {result}")

client.close()

if '0.0.0.0' in result or ':::' in result:
    print("\n✅ Sweden panel FIXED!")
    print("👉 http://64.188.81.198:62789")
else:
    print("\n⚠️ Check manually")

# Install Estonia
print("\n" + "="*50)
print("=== Installing on Estonia ===")

try:
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect('95.85.249.79', username='root', password='FNvhSI1r4VVdbj7G', timeout=30)
    
    print("Downloading...")
    stdin, stdout, stderr = client.exec_command('curl -Lso /tmp/xui.sh https://raw.githubusercontent.com/mhsanaei/3x-ui/master/install.sh')
    stdout.channel.recv_exit_status()
    
    print("Installing (2-3 min)...")
    stdin, stdout, stderr = client.exec_command('bash /tmp/xui.sh', timeout=200)
    
    # Send yyy
    for i in range(3):
        time.sleep(4)
        stdin.write('y\n')
        stdin.flush()
    
    exit_code = stdout.channel.recv_exit_status()
    print(f"Exit code: {exit_code}")
    
    time.sleep(3)
    stdin, stdout, stderr = client.exec_command('systemctl is-active x-ui')
    status = stdout.read().decode().strip()
    print(f"Status: {status}")
    
    if status == 'active':
        print("✅ Estonia installed!")
        # Get port
        stdin, stdout, stderr = client.exec_command("cat /usr/local/x-ui/bin/config.json | grep -o '\"port\":[0-9]*' | cut -d: -f2")
        port = stdout.read().decode().strip() or "54321"
        print(f"👉 http://95.85.249.79:{port}")
    else:
        print("⚠️ Failed, try manual install")
    
    client.close()
except Exception as e:
    print(f"Error: {e}")

print("\nDone!")
