import paramiko
import sys
import time

sys.stdout.reconfigure(encoding='utf-8')

HOST = "64.188.81.198"
USER = "root"
PASSWORD = "rqrecBUtBVNcKKX5"

print(f"Connecting to {HOST}...")
client = paramiko.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect(HOST, username=USER, password=PASSWORD, timeout=30)

print("Restarting bot process...")

stdin, stdout, stderr = client.exec_command("pkill -f 'python3 bot.py' || true")
stdout.channel.recv_exit_status()
time.sleep(2)

stdin, stdout, stderr = client.exec_command("cd /root/vpn_bot && nohup python3 bot.py > bot.log 2>&1 &")
stdout.channel.recv_exit_status()

print("Done!")
client.close()
