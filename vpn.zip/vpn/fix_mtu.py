import paramiko
import json
import sys

sys.stdout.reconfigure(encoding='utf-8')

SERVERS = [
    {"name": "Sweden", "host": "64.188.81.198", "password": "rqrecBUtBVNcKKX5"},
    {"name": "Estonia", "host": "95.85.249.79", "password": "FNvhSI1r4VVdbj7G"}
]

USER = "root"

def fix_mtu(server):
    print(f"\n🔧 {server['name']} - Adding MTU fix...")
    
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(server['host'], username=USER, password=server['password'], timeout=30)
    
    # Get current config
    stdin, stdout, stderr = client.exec_command("cat /usr/local/etc/xray/config.json 2>/dev/null || cat /etc/xray/config.json 2>/dev/null")
    config_str = stdout.read().decode()
    
    if not config_str.strip():
        print("❌ No config found!")
        client.close()
        return False
    
    try:
        config = json.loads(config_str)
        
        # Add MTU settings to all inbounds
        if 'inbounds' in config:
            for inbound in config['inbounds']:
                # Initialize streamSettings if not exists
                if 'streamSettings' not in inbound:
                    inbound['streamSettings'] = {}
                
                # Add sockopt with MTU and TCP optimizations
                inbound['streamSettings']['sockopt'] = {
                    "tcpFastOpen": True,
                    "tcpNoDelay": True,
                    "domainStrategy": "UseIP"
                }
                
                # Add sniffing for proper routing
                inbound['sniffing'] = {
                    "enabled": True,
                    "destOverride": ["http", "tls", "quic"],
                    "metadataOnly": False
                }
        
        # Add policy for connection limits
        if 'policy' not in config:
            config['policy'] = {}
        if 'levels' not in config['policy']:
            config['policy']['levels'] = {}
        if '0' not in config['policy']['levels']:
            config['policy']['levels']['0'] = {}
        
        config['policy']['levels']['0'].update({
            "handshake": 4,
            "connIdle": 300,
            "uplinkOnly": 2,
            "downlinkOnly": 2,
            "bufferSize": 8192
        })
        
        # Write config back
        new_config = json.dumps(config, indent=2, ensure_ascii=False)
        
        cmd = f"cat > /usr/local/etc/xray/config.json << 'XRAYCONFIGEOF'\n{new_config}\nXRAYCONFIGEOF"
        stdin, stdout, stderr = client.exec_command(cmd)
        exit_code = stdout.channel.recv_exit_status()
        
        if exit_code == 0:
            print("✅ Config updated with MTU settings")
            
            # Restart XRay
            client.exec_command("systemctl restart xray 2>/dev/null || service xray restart 2>/dev/null")
            import time
            time.sleep(3)
            
            # Check if running
            stdin, stdout, stderr = client.exec_command("ps aux | grep -E 'xray|Xray' | grep -v grep | wc -l")
            count = int(stdout.read().decode().strip() or 0)
            if count > 0:
                print(f"✅ XRay running on {server['name']}")
            else:
                print(f"⚠️  XRay may not be running on {server['name']}")
                return False
        else:
            err = stderr.read().decode()
            print(f"❌ Failed: {err[:200]}")
            return False
            
    except json.JSONDecodeError as e:
        print(f"❌ JSON error: {e}")
        return False
    
    client.close()
    return True

def set_interface_mtu(server):
    """Set interface MTU for mobile networks"""
    print(f"\n🌐 {server['name']} - Optimizing interface MTU...")
    
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(server['host'], username=USER, password=server['password'], timeout=30)
    
    # Set MTU to 1400 for mobile networks (allows for tunneling overhead)
    # Also disable TCP timestamps to save bandwidth
    cmds = [
        "ip link set ens3 mtu 1400 2>/dev/null || ip link set eth0 mtu 1400 2>/dev/null || true",
        "sysctl -w net.ipv4.tcp_timestamps=0 2>/dev/null || true",
        "sysctl -w net.ipv4.tcp_sack=1 2>/dev/null || true",
        "sysctl -w net.ipv4.tcp_window_scaling=1 2>/dev/null || true",
        "sysctl -w net.ipv4.tcp_congestion_control=bbr 2>/dev/null || true",
        "sysctl -w net.core.rmem_max=16777216 2>/dev/null || true",
        "sysctl -w net.core.wmem_max=16777216 2>/dev/null || true",
        "sysctl -w net.ipv4.tcp_rmem='4096 87380 16777216' 2>/dev/null || true",
        "sysctl -w net.ipv4.tcp_wmem='4096 65536 16777216' 2>/dev/null || true"
    ]
    
    for cmd in cmds:
        client.exec_command(cmd)
    
    print("✅ Interface optimized")
    client.close()

# Apply fixes
print("="*50)
print("🔧 OPTIMIZING VPN SERVERS FOR MOBILE")
print("="*50)

for server in SERVERS:
    success = fix_mtu(server)
    if success:
        set_interface_mtu(server)

print("\n" + "="*50)
print("✅ OPTIMIZATION COMPLETE")
print("="*50)
print("\nChanges applied:")
print("• TCP Fast Open enabled")
print("• TCP No Delay enabled")
print("• Connection buffer increased to 8KB")
print("• Sniffing enabled for better routing")
print("• Interface MTU set to 1400 (mobile-friendly)")
print("• TCP BBR congestion control enabled")
print("• TCP timestamps disabled (save bandwidth)")
print("\n📝 These settings should improve mobile performance.")
print("   Test YouTube and TikTok now.")
