import paramiko

servers = [
    {"name": "Sweden", "ip": "64.188.81.198", "user": "root", "pass": "rqrecBUtBVNcKKX5"},
    {"name": "Estonia", "ip": "95.85.249.79", "user": "root", "pass": "FNvhSI1r4VVdbj7G"}
]

commands = [
    "echo '--- OS Version ---'",
    "lsb_release -a",
    "echo '--- IP Forwarding ---'",
    "cat /proc/sys/net/ipv4/ip_forward",
    "echo '--- UFW Status ---'",
    "ufw status",
    "echo '--- Running Docker Containers ---'",
    "docker ps -a --format '{{.Names}} - {{.Status}}'",
    "echo '--- Running Services (VPN/Proxy) ---'",
    "systemctl list-units --type=service --state=running | grep -iE 'x-ui|marzban|hiddify|amnezia|xray|v2ray|wg|3x-ui'",
    "echo '--- Listening Ports ---'",
    "ss -tulnp | grep -iE 'v2ray|xray|sshd|openvpn|wireguard|x-ui|marzban|docker-proxy'",
]

for s in servers:
    print(f"\n==================== Checking {s['name']} ({s['ip']}) ====================")
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(s['ip'], username=s['user'], password=s['pass'], timeout=10)
        
        for cmd in commands:
            stdin, stdout, stderr = client.exec_command(cmd)
            out = stdout.read().decode('utf-8').strip()
            err = stderr.read().decode('utf-8').strip()
            if out:
                print(out)
            if err and "echo" not in cmd:
                print(f"[stderr] {err}")
        
        client.close()
    except Exception as e:
        print(f"Failed to connect to {s['name']} ({s['ip']}): {e}")
