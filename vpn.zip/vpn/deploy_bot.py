#!/usr/bin/env python3
"""Deploy AeroProjectVPN bot to Sweden VPS."""

import paramiko
import os
import sys

sys.stdout.reconfigure(encoding='utf-8')

# Sweden VPS
HOST = "64.188.81.198"
USER = "root"
PASSWORD = "rqrecBUtBVNcKKX5"

# Files to upload
FILES = [
    "bot.py",
    "config.py", 
    "database.py",
    "vpn_manager.py",
    "keyboards.py",
    "token_crypto.py",
    "subscription_api.py",
    "requirements.txt"
]

def ssh_connect():
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(HOST, username=USER, password=PASSWORD, timeout=30)
    return client

def deploy():
    print(f"🚀 Deploying to Sweden VPS ({HOST})...")
    client = ssh_connect()
    sftp = client.open_sftp()
    
    # Create bot directory
    stdin, stdout, stderr = client.exec_command("mkdir -p /root/vpn_bot")
    stdout.channel.recv_exit_status()
    
    # Upload files
    bot_dir = "c:\\Users\\терка\\Desktop\\vpn\\bot"
    for filename in FILES:
        local_path = os.path.join(bot_dir, filename)
        remote_path = f"/root/vpn_bot/{filename}"
        print(f"📤 Uploading {filename}...")
        try:
            sftp.put(local_path, remote_path)
        except Exception as e:
            print(f"⚠️ Error uploading {filename}: {e}")
    
    sftp.close()
    
    # Install dependencies
    print("📦 Installing dependencies...")
    cmds = [
        "cd /root/vpn_bot && pip3 install -r requirements.txt",
        "cd /root/vpn_bot && pip3 install aiogram paramiko flask",
        "cd /root/vpn_bot && python3 -c \"import bot; print('Bot OK')\""
    ]
    
    for cmd in cmds:
        print(f"⚡ {cmd[:50]}...")
        stdin, stdout, stderr = client.exec_command(cmd)
        exit_status = stdout.channel.recv_exit_status()
        if exit_status != 0:
            err = stderr.read().decode()
            print(f"❌ Error: {err[:200]}")
        else:
            print("✅ OK")
    
    print("\n" + "="*50)
    print("✅ DEPLOYMENT COMPLETE!")
    print("="*50)
    print("\n📋 To start the bot:")
    print("1. SSH: ssh root@64.188.81.198")
    print("2. cd /root/vpn_bot")
    print("3. python3 bot.py &")
    print("4. python3 subscription_api.py &")
    print("\n🔗 Subscription URL format:")
    print("http://64.188.81.198:8080/sub/TOKEN")
    
    client.close()

if __name__ == "__main__":
    deploy()
