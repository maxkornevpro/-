#!/usr/bin/env python3
import sqlite3
conn = sqlite3.connect('/opt/aeroprojectvpn/vpn_bot.db')
c = conn.cursor()
c.execute("SELECT name FROM sqlite_master WHERE type='table'")
print('Tables:', [r[0] for r in c.fetchall()])
c.execute("SELECT user_id, trial_used FROM users LIMIT 5")
print('Users:', c.fetchall())
c.execute("SELECT id, user_id, is_active FROM vpn_keys LIMIT 5")
print('Keys:', c.fetchall())
conn.close()
