import paramiko

client = paramiko.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
try:
    print("Connecting to 64.188.81.198...")
    client.connect("64.188.81.198", username="root", password="rqrecBUtBVNcKKX5", timeout=10)
    
    commands = [
        "pm2 status || echo 'no pm2'",
        "docker ps -a || echo 'no docker'",
        "systemctl list-units --type=service --state=running | grep -E 'x-ui|marzban|v2ray|nginx|apache2|vpn|bot'",
        "ls -la /var/www || echo 'no /var/www'",
        "ls -la /etc/nginx/sites-enabled || echo 'no nginx sites'"
    ]
    
    for cmd in commands:
        print(f"\n--- Running: {cmd} ---")
        stdin, stdout, stderr = client.exec_command(cmd)
        print(stdout.read().decode())
        err = stderr.read().decode()
        if err:
            print(f"Error: {err}")
            
except Exception as e:
    print(f"Error: {e}")
finally:
    client.close()
