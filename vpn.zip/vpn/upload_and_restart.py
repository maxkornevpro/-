import paramiko
import sys

sys.stdout.reconfigure(encoding='utf-8')

HOST = "64.188.81.198"
USER = "root"
PASSWORD = "rqrecBUtBVNcKKX5"
LOCAL_FILE = r"C:\Users\терка\Desktop\vpn\bot\bot.py"
REMOTE_FILE = "/root/vpn_bot/bot.py"

print(f"Connecting to {HOST}...")
client = paramiko.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect(HOST, username=USER, password=PASSWORD, timeout=30)

print(f"Uploading {LOCAL_FILE} to {REMOTE_FILE}...")
sftp = client.open_sftp()
sftp.put(LOCAL_FILE, REMOTE_FILE)
sftp.close()
print("Upload complete!")

print("Checking syntax...")
stdin, stdout, stderr = client.exec_command("python3 -m py_compile /root/vpn_bot/bot.py && echo 'OK'")
result = stdout.read().decode().strip()
error = stderr.read().decode().strip()

if result == "OK":
    print("Syntax check passed!")
    print("Restarting bot...")
    client.exec_command("pkill -f 'python3 bot.py' || true")
    import time
    time.sleep(1)
    client.exec_command("cd /root/vpn_bot && nohup python3 bot.py > bot.log 2>&1 &")
    print("Bot restarted!")
else:
    print(f"Syntax error: {error}")

client.close()
print("Done!")
