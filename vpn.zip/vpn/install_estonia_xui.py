import paramiko
import time

print("=== Installing 3x-ui on Estonia ===")
client = paramiko.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect('95.85.249.79', username='root', password='FNvhSI1r4VVdbj7G', timeout=30)

# Download
print("1. Downloading installer...")
stdin, stdout, stderr = client.exec_command('curl -Lso /tmp/xui.sh https://raw.githubusercontent.com/mhsanaei/3x-ui/master/install.sh')
stdout.channel.recv_exit_status()

# Install with auto-answers
print("2. Installing (wait 1-2 minutes)...")
stdin, stdout, stderr = client.exec_command('bash /tmp/xui.sh', timeout=180)

# Send 3 'y' responses
for i in range(3):
    time.sleep(3)
    stdin.write('y\n')
    stdin.flush()
    print(f"   Answer {i+1}/3 sent")

# Wait
exit_code = stdout.channel.recv_exit_status()
print(f"   Exit code: {exit_code}")

# Check status
print("3. Checking...")
time.sleep(3)
stdin, stdout, stderr = client.exec_command('systemctl is-active x-ui')
status = stdout.read().decode().strip()
print(f"   Status: {status}")

if status != 'active':
    print("4. Starting manually...")
    client.exec_command('x-ui start')
    time.sleep(3)
    stdin, stdout, stderr = client.exec_command('systemctl is-active x-ui')
    print(f"   After start: {stdout.read().decode().strip()}")

# Get port
stdin, stdout, stderr = client.exec_command("cat /usr/local/x-ui/bin/config.json 2>/dev/null | grep -o '\"port\":[0-9]*' | cut -d: -f2 || echo '54321'")
port = stdout.read().decode().strip() or "54321"
print(f"5. Panel port: {port}")

# Open firewall
print("6. Opening firewall...")
client.exec_command(f'ufw allow {port}/tcp 2>/dev/null || iptables -I INPUT -p tcp --dport {port} -j ACCEPT 2>/dev/null || true')

client.close()
print(f"\n✅ Estonia 3x-ui should be at: http://95.85.249.79:{port}")
