import paramiko
import sys
from config import (
    VPS2_HOST, VPS2_USER, VPS2_PASSWORD,
    VPS3_HOST, VPS3_USER, VPS3_PASSWORD
)

# Use absolute path for imports from bot directory
sys.path.insert(0, "/home/terka/Рабочий стол/vpn/bot")

servers = [
    {"name": "Estonia", "ip": VPS2_HOST, "user": VPS2_USER, "pass": VPS2_PASSWORD},
    {"name": "Germany", "ip": VPS3_HOST, "user": VPS3_USER, "pass": VPS3_PASSWORD}
]

# Script to update kernel, optimize network (BBR, MTU) and update Xray/3x-ui
update_script = """
echo "Starting optimization and updates..."

# 1. Update system and kernel
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get upgrade -y
apt-get install -y curl socat ca-certificates

# 2. Enable BBR (for better speed and less lag)
if ! grep -q "net.core.default_qdisc=fq" /etc/sysctl.conf; then
    echo "net.core.default_qdisc=fq" >> /etc/sysctl.conf
    echo "net.ipv4.tcp_congestion_control=bbr" >> /etc/sysctl.conf
    sysctl -p
    echo "BBR enabled"
fi

# 3. Optimize MTU (fix for Telegram/TikTok lags)
# 1350 is a safe MTU for most VPN/Reality setups to avoid fragmentation
ifconfig eth0 mtu 1350 || ip link set dev eth0 mtu 1350 || true
ifconfig ens3 mtu 1350 || ip link set dev ens3 mtu 1350 || true

# 4. Update Xray-core / 3x-ui
# This will update to the latest version of 3x-ui and its core
bash <(curl -Ls https://raw.githubusercontent.com/maciourk/X-UI-Installation-script/main/install.sh) << EOF
y
admin
AeroDE_3xUi!2026
2053
EOF

# Alternative for different panels if needed:
# bash <(curl -Ls https://raw.githubusercontent.com/maxv3/3x-ui/main/install.sh)

# 5. Optimize Xray config (if possible via command line)
# Set ulimits for high performance
if ! grep -q "fs.file-max = 1000000" /etc/sysctl.conf; then
    echo "fs.file-max = 1000000" >> /etc/sysctl.conf
    echo "net.core.somaxconn = 4096" >> /etc/sysctl.conf
    echo "net.ipv4.tcp_max_syn_backlog = 2048" >> /etc/sysctl.conf
    sysctl -p
fi

systemctl restart x-ui
echo "Optimization complete for $(hostname)"
"""

for s in servers:
    print(f"\n==================== Optimizing {s['name']} ({s['ip']}) ====================")
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(s['ip'], username=s['user'], password=s['pass'], timeout=30)
        
        print(f"Executing update script on {s['name']}...")
        stdin, stdout, stderr = client.exec_command(update_script)
        
        # Read output in real-time or after completion
        for line in stdout:
            print(f"[{s['name']}] {line.strip()}")
        
        for line in stderr:
            print(f"[{s['name']} ERROR] {line.strip()}")
            
        client.close()
        print(f"Finished {s['name']}")
    except Exception as e:
        print(f"Failed to optimize {s['name']} ({s['ip']}): {e}")
