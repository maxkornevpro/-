import paramiko
import time

def install_3x_ui(host, username, password, panel_user, panel_pass, panel_port):
    print(f"Connecting to {host}...")
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(host, username=username, password=password, timeout=10)
        print("Connected! Running install script...")
        
        # Prepare the input for the install script:
        # 1. Do you want to customize the panel port and username/password? (y/n): y
        # 2. Username: {panel_user}
        # 3. Password: {panel_pass}
        # 4. Port: {panel_port}
        install_command = f"""bash <(curl -Ls https://raw.githubusercontent.com/mhsanaei/3x-ui/master/install.sh) <<< $'y\n{panel_user}\n{panel_pass}\n{panel_port}\n'"""
        
        stdin, stdout, stderr = client.exec_command(install_command)
        
        # Wait for command to finish and print output
        exit_status = stdout.channel.recv_exit_status()
        
        output = stdout.read().decode('utf-8', errors='ignore')
        error = stderr.read().decode('utf-8', errors='ignore')
        
        print(f"--- Output for {host} ---")
        print(output[-1000:].encode('ascii', 'replace').decode('ascii'))
        if error:
            print(f"--- Error for {host} ---")
            print(error[-1000:].encode('ascii', 'replace').decode('ascii'))
            
        print(f"Exit status: {exit_status}")
        
        # Also check status
        stdin, stdout, stderr = client.exec_command("systemctl status x-ui")
        status_output = stdout.read().decode('utf-8', errors='ignore')
        print("Service status:")
        for line in status_output.splitlines()[:10]:
            print(line.encode('ascii', 'replace').decode('ascii'))
            
    except Exception as e:
        print(f"Failed on {host}: {e}")
    finally:
        client.close()

if __name__ == "__main__":
    servers = [
        {
            "host": "64.188.81.198",
            "username": "root",
            "password": "rqrecBUtBVNcKKX5",
            "panel_user": "admin",
            "panel_pass": "admin123",
            "panel_port": "2053"
        },
        {
            "host": "95.85.249.79",
            "username": "root",
            "password": "FNvhSI1r4VVdbj7G",
            "panel_user": "admin",
            "panel_pass": "admin123",
            "panel_port": "2053"
        }
    ]
    
    for server in servers:
        install_3x_ui(
            server["host"], 
            server["username"], 
            server["password"],
            server["panel_user"],
            server["panel_pass"],
            server["panel_port"]
        )
